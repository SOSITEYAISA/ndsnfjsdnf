"use client"

import { X } from "lucide-react"

interface TransactionConfirmationModalProps {
  isOpen: boolean
  onClose: () => void
  onConfirm: () => void
  solBalance: number
  hasBeenOpened?: boolean
}

export default function TransactionConfirmationModal({
  isOpen,
  onClose,
  onConfirm,
  solBalance,
  hasBeenOpened = false,
}: TransactionConfirmationModalProps) {
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 max-[393px]:p-0 max-[393px]:items-end z-[1002]">
      <div
        className={`bg-[rgb(25,25,25)] rounded-[24px] w-full max-w-[400px] text-white relative max-[393px]:rounded-b-none max-[393px]:max-w-none max-[393px]:mb-0 transaction-modal ${!hasBeenOpened ? "first-open" : "already-opened"}`}
      >
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-[19px] right-[19px] w-[32px] h-[32px] rounded-full bg-[#343434] flex items-center justify-center hover:bg-[#404040] transition-colors"
        >
          <X className="w-[20px] h-[20px] text-[#8a8a8a]" />
        </button>

        {/* Header */}
        <div className="pt-[19px] px-[19px] pb-[26px]">
          <h1 className="text-[26px] font-normal text-white mb-[10px] leading-[1.1] tracking-[-0.02em]">
            Transaction
            <br />
            confirmation
          </h1>
        </div>

        {/* Solana Balance */}
        <div className="mx-[19px] mb-[9.5px]">
          <div className="bg-[#343434] rounded-[13px] px-[16px] py-[13px] flex items-center justify-between">
            <div className="flex items-center gap-[12px]">
              <img
                src="https://i.ibb.co/sJv5MH4n/2e622e1b59d44356881e687b625387c1.png"
                alt="Solana"
                className="w-[32px] h-[32px] rounded-full"
              />
              <span className="text-white text-[18px] font-normal">Solana</span>
            </div>
            <span className="text-[#22C55E] text-[18px] font-medium">+10.82 SOL</span>
          </div>
        </div>

        {/* Transaction Details */}
        <div className="mx-[19px] mb-[9.5px]">
          <div className="bg-[#343434] rounded-[13px] px-[16px] py-[16px]">
            <div className="space-y-[16px]">
              <div className="flex justify-between items-center">
                <span className="text-white text-[18px] font-normal">Account</span>
                <span className="text-[#8a8a8a] text-[18px] font-normal">Account 1</span>
              </div>
              <div className="h-[2px] bg-[#2b2b2b] mx-[-16px]"></div>
              <div className="flex justify-between items-center">
                <span className="text-white text-[18px] font-normal">Network</span>
                <div className="flex items-center gap-[8px]">
                  <img
                    src="https://i.ibb.co/sJv5MH4n/2e622e1b59d44356881e687b625387c1.png"
                    alt="Solana"
                    className="w-[16px] h-[16px] rounded-full"
                  />
                  <span className="text-[#8a8a8a] text-[18px] font-normal">Solana</span>
                </div>
              </div>
              <div className="h-[2px] bg-[#2b2b2b] mx-[-16px]"></div>
              <div className="flex justify-between items-center">
                <span className="text-white text-[18px] font-normal">Network Fee</span>
                <span className="text-[#8a8a8a] text-[18px] font-normal">~0.0001 SOL</span>
              </div>
            </div>
          </div>
        </div>

        {/* Additional Info */}
        <div className="mx-[19px] mb-[26px]">
          <div className="bg-[#343434] rounded-[13px] px-[16px] py-[13px] flex items-center justify-between cursor-pointer hover:bg-[#404040] transition-colors">
            <span className="text-white text-[18px] font-normal">Additional</span>
            <svg
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              className="text-[#8a8a8a]"
            >
              <polyline points="9 18 15 12 9 6" />
            </svg>
          </div>
        </div>

        {/* Buttons */}
        <div className="px-[19px] pb-[19px] flex gap-[10px] max-[393px]:pb-[26px]">
          <button
            onClick={onClose}
            className="flex-1 bg-[#343434] hover:bg-[#404040] text-white rounded-[13px] h-[49px] text-[17px] font-medium transition-colors scale-x-130"
          >
            Close
          </button>
          <button
            onClick={onConfirm}
            className="flex-1 bg-[rgb(171,159,241)] hover:bg-[rgb(161,149,231)] text-black rounded-[13px] h-[49px] text-[17px] font-medium transition-colors scale-x-130"
          >
            Confirm
          </button>
        </div>

        {/* Footer Warning */}
        <div className="px-[19px] pb-[19px] text-center">
          <p className="text-[#8a8a8a] text-[10px] leading-[1.4]">Confirm only if you trust this site.</p>
        </div>
      </div>
    </div>
  )
}
