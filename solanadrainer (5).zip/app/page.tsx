"use client"

import { useState, useEffect } from "react"
import {
  Menu,
  X,
  Star,
  Play,
  ExternalLink,
  CheckCircle,
  Shield,
  TrendingUp,
  Copy,
  Info,
  Calendar,
  CheckSquare,
  PieChart,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "@/hooks/use-toast"
import Image from "next/image"
import SolanaWalletScanner from "../solana-wallet-scanner"

interface Transaction {
  id: string
  address: string
  amount: number
  timeAgo: number
}

interface FAQItem {
  question: string
  answer: string
}

export default function HomePage() {
  // Header state
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  // Fixed price for MORI coin
  const coinPrice = {
    price: "$0.12574",
    change: "+2.45%",
    isPositive: true,
  }

  // Hero state
  const [copied, setCopied] = useState(false)

  // Transactions state
  const [transactions, setTransactions] = useState<Transaction[]>([])

  // FAQ state
  const [openFAQ, setOpenFAQ] = useState<number | null>(null)

  // Wallet Scanner State
  const [isWalletScannerOpen, setIsWalletScannerOpen] = useState(false)

  const contractAddress = "8ZHE4ow1a2jjxuoMfyExuNamQNALv5ekZhsBn5nMDf5e"

  const faqItems: FAQItem[] = [
    {
      question: "What is the MORI Airdrop?",
      answer:
        "The MORI Airdrop is a large-scale token distribution event designed to reward early supporters and build a strong community around the $MORI ecosystem. We're distributing 1,000,000 $MORI tokens completely free to qualified participants.",
    },
    {
      question: "How do I participate?",
      answer:
        "To participate, you need to: 1) Follow our social media accounts, 2) Connect a valid Solana wallet, 3) Complete community tasks and referral programs. All requirements are listed in the participation section.",
    },
    {
      question: "When will tokens be distributed?",
      answer:
        "Token distribution happens in three phases: Phase 1 (June 15 - July 8, 2025), Phase 2 (July 9 - August 8, 2025), and Phase 3 (August 9 - September 8, 2025). Tokens are distributed automatically upon meeting requirements.",
    },
    {
      question: "What blockchain is MORI built on?",
      answer:
        "MORI is built on the Solana blockchain, offering fast transactions, low fees, and high scalability. This ensures efficient token distribution and optimal user experience.",
    },
    {
      question: "Is there a limit to how many tokens I can receive?",
      answer:
        "Yes, each wallet can receive up to 10,000 $MORI tokens. The exact amount depends on your participation level and the phase you join during.",
    },
  ]

  // Scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  // Transactions simulation
  const generateAddress = () => {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz123456789"
    let result = ""
    for (let i = 0; i < 44; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length))
    }
    return result
  }

  const formatAddress = (address: string) => {
    return `${address.slice(0, 4)}...${address.slice(-4)}`
  }

  const formatTimeAgo = (seconds: number) => {
    if (seconds < 60) return `${seconds}s ago`
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`
    return `${Math.floor(seconds / 3600)}h ago`
  }

  const amounts = [250, 500, 750, 1000, 1250, 1500, 2000, 2500, 3000, 5000]

  useEffect(() => {
    // Initialize with some transactions
    const initialTransactions: Transaction[] = Array.from({ length: 10 }, (_, i) => ({
      id: `tx-${i}`,
      address: generateAddress(),
      amount: amounts[Math.floor(Math.random() * amounts.length)],
      timeAgo: Math.floor(Math.random() * 3600) + i * 30,
    }))
    setTransactions(initialTransactions)

    // Add new transactions periodically
    const interval = setInterval(
      () => {
        const newTransaction: Transaction = {
          id: `tx-${Date.now()}`,
          address: generateAddress(),
          amount: amounts[Math.floor(Math.random() * amounts.length)],
          timeAgo: Math.floor(Math.random() * 300),
        }

        setTransactions((prev) => [newTransaction, ...prev.slice(0, 19)])
      },
      Math.random() * 5000 + 3000,
    )

    return () => clearInterval(interval)
  }, [])

  // Functions
  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(contractAddress)
      setCopied(true)
      toast({
        title: "Copied!",
        description: "Contract address copied to clipboard",
      })
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      console.error("Failed to copy:", err)
    }
  }

  const openWalletScanner = () => {
    setIsWalletScannerOpen(true)
  }

  const toggleFAQ = (index: number) => {
    setOpenFAQ(openFAQ === index ? null : index)
  }

  return (
    <div className="min-h-screen bg-black text-white overflow-x-hidden">
      {/* Header - Improved Mobile Responsiveness */}
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled
            ? "bg-black/95 backdrop-blur-lg border-b border-yellow-500/20 shadow-lg"
            : "bg-black/85 backdrop-blur-md border-b border-yellow-500/10"
        }`}
      >
        <div className="max-w-7xl mx-auto px-3 sm:px-4 h-16 sm:h-20 flex items-center justify-between">
          {/* Logo - Mobile Optimized */}
          <div className="flex items-center cursor-pointer flex-shrink-0">
            <Image
              src="/images/logo.png"
              alt="MORI Logo"
              width={36}
              height={36}
              className="rounded-full sm:w-12 sm:h-12"
            />
            <span className="ml-2 text-lg sm:text-xl font-bold">MORI</span>
          </div>

          {/* Price Display - Mobile Optimized */}
          <div className="hidden sm:flex items-center ml-4 lg:ml-8 mr-auto">
            <div className="bg-white/5 border border-yellow-500/20 rounded-xl px-3 lg:px-4 py-2 backdrop-blur-sm">
              <div className="flex items-center gap-2">
                <span className="text-yellow-500 font-semibold text-sm lg:text-base">$MORI</span>
                <span className="text-white font-semibold text-sm lg:text-base">{coinPrice.price}</span>
                <span className="text-sm px-2 py-1 rounded text-green-400 bg-green-400/10">{coinPrice.change}</span>
              </div>
            </div>
          </div>

          {/* Mobile Price Display */}
          <div className="flex sm:hidden items-center mx-2 flex-1 justify-center">
            <div className="bg-white/5 border border-yellow-500/20 rounded-lg px-2 py-1 backdrop-blur-sm">
              <div className="flex items-center gap-1">
                <span className="text-yellow-500 font-semibold text-xs">$MORI</span>
                <span className="text-white font-semibold text-xs">{coinPrice.price}</span>
                <span className="text-xs px-1 py-0.5 rounded text-green-400 bg-green-400/10">{coinPrice.change}</span>
              </div>
            </div>
          </div>

          {/* Navigation - Mobile Optimized */}
          <nav className="flex items-center gap-2 sm:gap-4">
            {/* Language Switcher - Hidden on small mobile */}
            <div className="hidden md:flex bg-white/5 rounded-full p-1 border border-yellow-500/20">
              <button className="px-3 py-1 rounded-full text-sm font-semibold text-gray-400 hover:text-yellow-500 transition-colors">
                RU
              </button>
              <button className="px-3 py-1 rounded-full text-sm font-semibold bg-yellow-500 text-black transition-colors">
                EN
              </button>
            </div>

            {/* Buy Button - Desktop Only */}
            <Button
              className="hidden lg:flex bg-gradient-to-r from-yellow-500 to-yellow-400 text-black font-bold px-4 xl:px-6 py-2 rounded-full hover:from-yellow-400 hover:to-yellow-300 transition-all duration-300 transform hover:scale-105 text-sm"
              onClick={() =>
                window.open("https://jup.ag/swap/SOL-8ZHE4ow1a2jjxuoMfyExuNamQNALv5ekZhsBn5nMDf5e", "_blank")
              }
            >
              Buy $MORI
            </Button>

            {/* Social Icons - Mobile Optimized */}
            <div className="hidden sm:flex items-center gap-1 sm:gap-2">
              <a
                href="https://x.com/MoriCoinCrypto"
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 sm:w-10 sm:h-10 bg-white/5 rounded-lg flex items-center justify-center hover:bg-yellow-500/20 transition-colors border border-white/10"
              >
                <span className="text-white text-xs sm:text-sm">𝕏</span>
              </a>
              <a
                href="https://www.youtube.com/@moriartymega"
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 sm:w-10 sm:h-10 bg-white/5 rounded-lg flex items-center justify-center hover:bg-yellow-500/20 transition-colors border border-white/10"
              >
                <span className="text-white text-xs sm:text-sm">▶</span>
              </a>
              <a
                href="https://t.me/moricoin_official"
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 sm:w-10 sm:h-10 bg-white/5 rounded-lg flex items-center justify-center hover:bg-yellow-500/20 transition-colors border border-white/10"
              >
                <span className="text-white text-xs sm:text-sm">✈</span>
              </a>
            </div>

            {/* Mobile Menu Button */}
            <button
              className="w-8 h-8 sm:w-10 sm:h-10 flex items-center justify-center"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X size={18} className="sm:w-5 sm:h-5" /> : <Menu size={18} className="sm:w-5 sm:h-5" />}
            </button>
          </nav>
        </div>

        {/* Progress Bar */}
        <div
          className="absolute bottom-0 left-0 h-1 bg-gradient-to-r from-yellow-500 to-yellow-400 transform origin-left scale-x-0 transition-transform duration-300"
          style={{ transform: `scaleX(${isScrolled ? 0.3 : 0})` }}
        />
      </header>

      {/* Mobile Menu - Improved */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-40 bg-black/95 backdrop-blur-lg">
          <div className="flex flex-col items-center justify-center h-full space-y-6 px-4">
            {/* Mobile Price Display in Menu */}
            <div className="text-center">
              <div className="text-yellow-500 font-semibold mb-2">$MORI Price</div>
              <div className="text-2xl font-bold">{coinPrice.price}</div>
              <div className="text-sm text-green-400">{coinPrice.change}</div>
            </div>

            {/* Social Links */}
            <div className="flex gap-4 sm:hidden">
              <a
                href="https://x.com/MoriCoinCrypto"
                target="_blank"
                rel="noopener noreferrer"
                className="w-12 h-12 bg-white/5 rounded-lg flex items-center justify-center hover:bg-yellow-500/20 transition-colors border border-white/10"
              >
                <span className="text-white">𝕏</span>
              </a>
              <a
                href="https://www.youtube.com/@moriartymega"
                target="_blank"
                rel="noopener noreferrer"
                className="w-12 h-12 bg-white/5 rounded-lg flex items-center justify-center hover:bg-yellow-500/20 transition-colors border border-white/10"
              >
                <span className="text-white">▶</span>
              </a>
              <a
                href="https://t.me/moricoin_official"
                target="_blank"
                rel="noopener noreferrer"
                className="w-12 h-12 bg-white/5 rounded-lg flex items-center justify-center hover:bg-yellow-500/20 transition-colors border border-white/10"
              >
                <span className="text-white">✈</span>
              </a>
            </div>

            <Button
              className="bg-gradient-to-r from-yellow-500 to-yellow-400 text-black font-bold px-8 py-3 rounded-full w-full max-w-xs"
              onClick={() => {
                window.open("https://jup.ag/swap/SOL-8ZHE4ow1a2jjxuoMfyExuNamQNALv5ekZhsBn5nMDf5e", "_blank")
                setIsMenuOpen(false)
              }}
            >
              Buy $MORI
            </Button>

            <div className="flex gap-4">
              <button className="px-4 py-2 text-gray-400 hover:text-yellow-500">RU</button>
              <button className="px-4 py-2 bg-yellow-500 text-black rounded-lg">EN</button>
            </div>
          </div>
        </div>
      )}

      <main>
        {/* Hero Section - Mobile Optimized */}
        <section className="min-h-screen bg-gradient-to-br from-black to-gray-900 relative overflow-hidden pt-16 sm:pt-20">
          {/* Background Effects */}
          <div className="absolute inset-0">
            <div className="absolute top-1/4 left-1/4 w-64 h-64 sm:w-96 sm:h-96 bg-yellow-500/10 rounded-full blur-3xl" />
            <div className="absolute bottom-1/4 right-1/4 w-64 h-64 sm:w-96 sm:h-96 bg-yellow-500/5 rounded-full blur-3xl" />
            {/* Background Image */}
            <div className="absolute bottom-0 left-0 w-full h-1/2 opacity-20">
              <Image src="/images/mori-arty.png" alt="Background" fill className="object-contain object-bottom" />
            </div>
          </div>

          <div className="max-w-7xl mx-auto px-4 py-10 sm:py-20 relative z-10">
            <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
              {/* Content */}
              <div className="space-y-6 sm:space-y-8">
                {/* Badge */}
                <div className="inline-flex items-center gap-2 bg-yellow-500/10 border border-yellow-500/30 rounded-full px-3 sm:px-4 py-2">
                  <Star className="w-3 h-3 sm:w-4 sm:h-4 text-yellow-500" />
                  <span className="text-yellow-500 font-semibold text-xs sm:text-sm">Exclusive MORI Airdrop</span>
                </div>

                {/* Title */}
                <div className="space-y-4">
                  <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
                    Hold the coin? Professor appreciates,
                    <br />
                    <span className="bg-gradient-to-r from-yellow-500 to-yellow-400 bg-clip-text text-transparent">
                      you will be rewarded.
                    </span>
                  </h1>

                  <p className="text-lg sm:text-xl text-gray-300 leading-relaxed">
                    You thought this was just a "Chat"? No! This is a special reward of{" "}
                    <strong className="text-yellow-500">10,000 $MORI per wallet</strong> for holders. Connect to the
                    $MORI ecosystem and claim your reward. $MORI is not just a meme, it's something much bigger.
                  </p>
                </div>

                {/* Stats - Mobile Optimized */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-6 py-6 sm:py-8">
                  <div className="text-center">
                    <div className="text-2xl sm:text-3xl font-bold text-yellow-500">1M</div>
                    <div className="text-xs sm:text-sm text-gray-400 uppercase tracking-wide">Total Coins</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl sm:text-3xl font-bold text-yellow-500">10K+</div>
                    <div className="text-xs sm:text-sm text-gray-400 uppercase tracking-wide">Participants</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl sm:text-3xl font-bold text-yellow-500">3</div>
                    <div className="text-xs sm:text-sm text-gray-400 uppercase tracking-wide">Phases</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl sm:text-3xl font-bold text-yellow-500">0</div>
                    <div className="text-xs sm:text-sm text-gray-400 uppercase tracking-wide">Fees</div>
                  </div>
                </div>

                {/* Action Buttons - Mobile Optimized */}
                <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
                  <Button
                    onClick={openWalletScanner}
                    className="bg-gradient-to-r from-yellow-500 to-yellow-400 text-black font-bold px-6 sm:px-8 py-3 sm:py-4 rounded-full hover:from-yellow-400 hover:to-yellow-300 transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-2"
                  >
                    <Play className="w-4 h-4 sm:w-5 sm:h-5" />
                    Claim Reward
                  </Button>

                  <Button
                    variant="outline"
                    onClick={() => window.open("https://t.me/moricoin_official", "_blank")}
                    className="border-yellow-500 text-yellow-500 hover:bg-yellow-500 hover:text-black px-6 sm:px-8 py-3 sm:py-4 rounded-full transition-all duration-300 flex items-center justify-center gap-2"
                  >
                    <ExternalLink className="w-4 h-4 sm:w-5 sm:h-5" />
                    Learn More
                  </Button>
                </div>

                {/* Contract Address - Mobile Optimized */}
                <div className="bg-white/5 border border-yellow-500/20 rounded-xl p-3 sm:p-4 backdrop-blur-sm">
                  <div className="flex flex-col gap-3 sm:flex-row sm:gap-4">
                    <div className="flex-1">
                      <div className="text-xs sm:text-sm text-gray-400 mb-1">Contract Address:</div>
                      <div className="font-mono text-xs sm:text-sm text-white break-all">{contractAddress}</div>
                    </div>
                    <Button
                      onClick={copyToClipboard}
                      variant="outline"
                      size="sm"
                      className="border-yellow-500/50 text-yellow-500 hover:bg-yellow-500 hover:text-black transition-colors bg-transparent w-full sm:w-auto"
                    >
                      <Copy className="w-3 h-3 sm:w-4 sm:h-4 mr-2" />
                      {copied ? "Copied!" : "Copy"}
                    </Button>
                  </div>
                </div>

                {/* Features - Mobile Optimized */}
                <div className="flex flex-col sm:flex-row sm:flex-wrap gap-4 sm:gap-6 pt-4">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 sm:w-5 sm:h-5 text-yellow-500 flex-shrink-0" />
                    <span className="text-sm sm:text-base text-gray-300">Instant Distribution</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Shield className="w-4 h-4 sm:w-5 sm:h-5 text-yellow-500 flex-shrink-0" />
                    <span className="text-sm sm:text-base text-gray-300">Security & Verification</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5 text-yellow-500 flex-shrink-0" />
                    <span className="text-sm sm:text-base text-gray-300">High Potential</span>
                  </div>
                </div>
              </div>

              {/* Visual - Mobile Optimized */}
              <div className="flex justify-center lg:justify-end mt-8 lg:mt-0">
                <div className="relative">
                  <div className="w-64 h-64 sm:w-80 sm:h-80 bg-gradient-to-br from-yellow-500/20 to-yellow-400/10 rounded-full blur-xl absolute inset-0" />
                  <div className="relative w-64 h-64 sm:w-80 sm:h-80 flex items-center justify-center">
                    <Image
                      src="/images/airdrop-illustration.png"
                      alt="MORI Airdrop Illustration"
                      width={256}
                      height={256}
                      className="object-contain sm:w-80 sm:h-80"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Combined Airdrop Section */}
        <div className="bg-gradient-to-b from-black to-gray-900 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-yellow-500/5 to-transparent pointer-events-none" />

          {/* Decorative Coins - Hidden on mobile */}
          <div className="absolute left-4 sm:left-8 top-20 opacity-30 hidden sm:block">
            <Image
              src="/images/coin-left1.png"
              alt="Decorative Coin"
              width={100}
              height={100}
              className="object-contain lg:w-36 lg:h-36"
            />
          </div>
          <div className="absolute right-4 sm:right-8 bottom-20 opacity-30 hidden sm:block">
            <Image
              src="/images/coin-left2.png"
              alt="Decorative Coin"
              width={100}
              height={100}
              className="object-contain lg:w-36 lg:h-36"
            />
          </div>

          {/* Live Transactions - Mobile Optimized */}
          <section className="py-10 sm:py-20 px-4">
            <div className="max-w-6xl mx-auto">
              <div className="flex flex-col lg:flex-row justify-between items-start mb-8 sm:mb-12 gap-6 sm:gap-8">
                <div className="flex-1">
                  <h2 className="text-3xl sm:text-4xl font-bold mb-4">Latest MORI Recipients</h2>
                  <p className="text-gray-400 text-base sm:text-lg">
                    Track real-time coin distribution on the Solana network
                  </p>
                </div>

                <div className="flex items-center gap-2 bg-green-500/10 border border-green-500/20 rounded-full px-3 sm:px-4 py-2">
                  <div className="w-4 h-4 sm:w-5 sm:h-5 bg-green-500 rounded-full flex items-center justify-center">
                    <span className="text-black text-xs font-bold">S</span>
                  </div>
                  <span className="text-green-500 font-semibold text-sm sm:text-base">Solana Network</span>
                </div>
              </div>

              <div className="bg-white/5 border border-yellow-500/10 rounded-2xl p-3 sm:p-6 backdrop-blur-sm max-h-80 sm:max-h-96 overflow-y-auto">
                <div className="space-y-3 sm:space-y-4">
                  {transactions.map((tx) => (
                    <div
                      key={tx.id}
                      className="flex items-center justify-between p-3 sm:p-4 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-colors"
                    >
                      <div className="flex-1">
                        <div className="font-mono text-white font-semibold mb-1 text-sm sm:text-base">
                          {formatAddress(tx.address)}
                        </div>
                        <div className="text-gray-500 text-xs sm:text-sm">{formatTimeAgo(tx.timeAgo)}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-yellow-500 font-bold text-base sm:text-lg">
                          {tx.amount.toLocaleString()} MORI
                        </div>
                        <div className="text-gray-500 text-xs sm:text-sm uppercase tracking-wide">Received</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </section>

          {/* About Section - Mobile Optimized */}
          <section className="py-10 sm:py-20 px-4 relative">
            <div className="max-w-6xl mx-auto">
              <div className="text-center mb-12 sm:mb-16">
                <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6 uppercase tracking-wider">
                  About Token
                </h2>
              </div>

              <div className="bg-black border border-yellow-500/20 rounded-2xl p-4 sm:p-8 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-24 h-16 sm:w-32 sm:h-24 opacity-20">
                  <div className="grid grid-cols-6 sm:grid-cols-8 gap-1 h-full">
                    {Array.from({ length: 48 }).map((_, i) => (
                      <div key={i} className="w-1 h-1 bg-yellow-500/50 rounded-full" />
                    ))}
                  </div>
                </div>

                <div className="grid lg:grid-cols-2 gap-8 sm:gap-12 items-center">
                  <div className="space-y-4 sm:space-y-6">
                    <h3 className="text-xl sm:text-2xl font-semibold text-gray-300">
                      About Professor Moriarty as Creator
                    </h3>
                    <p className="text-gray-300 leading-relaxed text-sm sm:text-base">
                      Professor Moriarty is not just a character from literature, but a symbol of intellectual
                      superiority and strategic thinking. In the world of cryptocurrency, he represents innovation,
                      cunning, and the ability to see opportunities where others see only chaos.
                    </p>
                    <ul className="space-y-2 sm:space-y-3 text-gray-300 text-sm sm:text-base">
                      <li className="flex items-start gap-3">
                        <span className="text-yellow-500 font-bold">•</span>
                        <span>Mastermind behind revolutionary blockchain technology</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <span className="text-yellow-500 font-bold">•</span>
                        <span>Creator of the most sophisticated tokenomics</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <span className="text-yellow-500 font-bold">•</span>
                        <span>Architect of decentralized financial systems</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <span className="text-yellow-500 font-bold">•</span>
                        <span>Pioneer in community-driven governance</span>
                      </li>
                    </ul>
                  </div>

                  <div className="flex justify-center">
                    <div className="relative">
                      <Image
                        src="/images/professor-moriarty.png"
                        alt="Professor Moriarty"
                        width={300}
                        height={300}
                        className="object-contain sm:w-96 sm:h-96"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Tokenomics Section - Mobile Optimized */}
          <section className="py-10 sm:py-20 px-4 relative">
            <div className="absolute inset-0 hidden lg:block">
              <Image
                src="/images/tokenomics-background.png"
                alt="Tokenomics Background"
                fill
                className="object-contain object-left opacity-30"
              />
            </div>

            <div className="max-w-6xl mx-auto relative z-10">
              <div className="text-center mb-12 sm:mb-16">
                <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6 uppercase tracking-wider">Tokenomics</h2>
              </div>

              <div className="grid lg:grid-cols-2 gap-8 sm:gap-12 items-center">
                <div className="space-y-6 sm:space-y-8">
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 sm:gap-6">
                    <div className="text-center group hover:scale-110 transition-transform cursor-default">
                      <div className="text-4xl sm:text-5xl lg:text-6xl font-bold bg-gradient-to-b from-gray-400 to-black bg-clip-text text-transparent mb-2">
                        40%
                      </div>
                      <div className="text-xs sm:text-sm text-gray-400 group-hover:text-yellow-500 transition-colors">
                        Community
                      </div>
                    </div>
                    <div className="text-center group hover:scale-110 transition-transform cursor-default">
                      <div className="text-4xl sm:text-5xl lg:text-6xl font-bold bg-gradient-to-b from-gray-400 to-black bg-clip-text text-transparent mb-2">
                        20%
                      </div>
                      <div className="text-xs sm:text-sm text-gray-400 group-hover:text-yellow-500 transition-colors">
                        Liquidity
                      </div>
                    </div>
                    <div className="text-center group hover:scale-110 transition-transform cursor-default">
                      <div className="text-4xl sm:text-5xl lg:text-6xl font-bold bg-gradient-to-b from-gray-400 to-black bg-clip-text text-transparent mb-2">
                        20%
                      </div>
                      <div className="text-xs sm:text-sm text-gray-400 group-hover:text-yellow-500 transition-colors">
                        Marketing
                      </div>
                    </div>
                    <div className="text-center group hover:scale-110 transition-transform cursor-default col-span-1 sm:col-span-1">
                      <div className="text-4xl sm:text-5xl lg:text-6xl font-bold bg-gradient-to-b from-gray-400 to-black bg-clip-text text-transparent mb-2">
                        10%
                      </div>
                      <div className="text-xs sm:text-sm text-gray-400 group-hover:text-yellow-500 transition-colors">
                        Team
                      </div>
                    </div>
                    <div className="text-center group hover:scale-110 transition-transform cursor-default col-span-1 sm:col-span-1">
                      <div className="text-4xl sm:text-5xl lg:text-6xl font-bold bg-gradient-to-b from-gray-400 to-black bg-clip-text text-transparent mb-2">
                        10%
                      </div>
                      <div className="text-xs sm:text-sm text-gray-400 group-hover:text-yellow-500 transition-colors">
                        Reserve
                      </div>
                    </div>
                  </div>

                  <div className="text-center">
                    <Button
                      className="bg-white text-black font-semibold px-6 sm:px-8 py-2 sm:py-3 rounded-lg hover:bg-gray-200 transition-colors text-sm sm:text-base"
                      onClick={() => window.open("https://solscan.io/token/" + contractAddress, "_blank")}
                    >
                      Check Contract
                    </Button>
                  </div>

                  <p className="text-gray-400 text-center text-sm sm:text-base">
                    MORI tokenomics are designed to ensure long-term sustainability and community growth. The
                    distribution model promotes fair allocation and incentivizes active participation in the ecosystem.
                  </p>
                </div>

                <div className="flex justify-center">
                  <div className="relative w-48 h-48 sm:w-64 sm:h-64">
                    <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                      <circle cx="50" cy="50" r="40" fill="none" stroke="#374151" strokeWidth="8" />
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        fill="none"
                        stroke="#EAB308"
                        strokeWidth="8"
                        strokeDasharray="100 251"
                        strokeDashoffset="0"
                        className="transition-all duration-1000"
                      />
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        fill="none"
                        stroke="#F59E0B"
                        strokeWidth="8"
                        strokeDasharray="50 251"
                        strokeDashoffset="-100"
                        className="transition-all duration-1000"
                      />
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        fill="none"
                        stroke="#D97706"
                        strokeWidth="8"
                        strokeDasharray="50 251"
                        strokeDashoffset="-150"
                        className="transition-all duration-1000"
                      />
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        fill="none"
                        stroke="#92400E"
                        strokeWidth="8"
                        strokeDasharray="25 251"
                        strokeDashoffset="-200"
                        className="transition-all duration-1000"
                      />
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        fill="none"
                        stroke="#78350F"
                        strokeWidth="8"
                        strokeDasharray="25 251"
                        strokeDashoffset="-225"
                        className="transition-all duration-1000"
                      />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Image
                        src="/images/logo.png"
                        alt="MORI Logo"
                        width={48}
                        height={48}
                        className="rounded-full sm:w-16 sm:h-16"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Airdrop Details - Mobile Optimized */}
          <section id="airdrop-details" className="py-10 sm:py-20 px-4">
            <div className="max-w-6xl mx-auto">
              {/* Header */}
              <div className="text-center mb-12 sm:mb-16">
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">About the $MORI Airdrop</h2>
                <p className="text-lg sm:text-xl text-gray-400 max-w-3xl mx-auto">
                  Everything you need to know about participating in the most anticipated token distribution of 2025
                </p>
              </div>

              {/* Details Grid - Mobile Optimized */}
              <div className="grid lg:grid-cols-2 gap-6 sm:gap-8 mb-12 sm:mb-16">
                {/* Main Info */}
                <Card className="bg-white/5 border-yellow-500/20 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3 text-yellow-500 text-lg sm:text-xl">
                      <Info className="w-5 h-5 sm:w-6 sm:h-6" />
                      What is the MORI Airdrop?
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 sm:space-y-4 text-gray-300 text-sm sm:text-base">
                    <p>
                      MORI Airdrop is a massive token distribution event designed to reward early supporters and create
                      a strong community around the $MORI ecosystem. We're distributing{" "}
                      <strong className="text-yellow-500">1,000,000 $MORI tokens</strong> completely free to qualified
                      participants.
                    </p>
                    <p>
                      Built on the Solana blockchain, MORI represents the future of decentralized finance with
                      innovative features and community-driven governance.
                    </p>
                  </CardContent>
                </Card>

                {/* Timeline */}
                <Card className="bg-white/5 border-yellow-500/20 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3 text-yellow-500 text-lg sm:text-xl">
                      <Calendar className="w-5 h-5 sm:w-6 sm:h-6" />
                      Airdrop Phases
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4 sm:space-y-6">
                    <div className="space-y-3 sm:space-y-4">
                      <div className="border-l-2 border-green-500 pl-3 sm:pl-4">
                        <div className="text-yellow-500 font-semibold text-sm sm:text-base">June 15 - July 8, 2025</div>
                        <div className="font-semibold text-sm sm:text-base">Phase 1: Early Adopters</div>
                        <div className="text-gray-400 text-xs sm:text-sm">
                          300,000 MORI for first 3,000 participants
                        </div>
                      </div>
                      <div className="border-l-2 border-yellow-500 pl-3 sm:pl-4">
                        <div className="text-yellow-500 font-semibold text-sm sm:text-base">
                          July 9 - August 8, 2025
                        </div>
                        <div className="font-semibold text-sm sm:text-base">Phase 2: Community Growth</div>
                        <div className="text-gray-400 text-xs sm:text-sm">500,000 MORI for community builders</div>
                      </div>
                      <div className="border-l-2 border-gray-500 pl-3 sm:pl-4">
                        <div className="text-yellow-500 font-semibold text-sm sm:text-base">
                          August 9 - September 8, 2025
                        </div>
                        <div className="font-semibold text-sm sm:text-base">Phase 3: Final Distribution</div>
                        <div className="text-gray-400 text-xs sm:text-sm">200,000 MORI for final participants</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Requirements */}
                <Card className="bg-white/5 border-yellow-500/20 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3 text-yellow-500 text-lg sm:text-xl">
                      <CheckSquare className="w-5 h-5 sm:w-6 sm:h-6" />
                      How to Participate
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 sm:space-y-4">
                      <div className="flex gap-3 sm:gap-4">
                        <div className="w-6 h-6 sm:w-8 sm:h-8 bg-yellow-500 text-black rounded-full flex items-center justify-center font-bold text-xs sm:text-sm flex-shrink-0">
                          1
                        </div>
                        <div>
                          <h4 className="font-semibold mb-1 text-sm sm:text-base">Follow Our Social Media</h4>
                          <p className="text-gray-400 text-xs sm:text-sm">
                            Follow @MoriCoinCrypto on Twitter and join our Telegram channel
                          </p>
                        </div>
                      </div>
                      <div className="flex gap-3 sm:gap-4">
                        <div className="w-6 h-6 sm:w-8 sm:h-8 bg-yellow-500 text-black rounded-full flex items-center justify-center font-bold text-xs sm:text-sm flex-shrink-0">
                          2
                        </div>
                        <div>
                          <h4 className="font-semibold mb-1 text-sm sm:text-base">Connect Solana Wallet</h4>
                          <p className="text-gray-400 text-xs sm:text-sm">
                            Provide a valid Solana wallet address to receive tokens
                          </p>
                        </div>
                      </div>
                      <div className="flex gap-3 sm:gap-4">
                        <div className="w-6 h-6 sm:w-8 sm:h-8 bg-yellow-500 text-black rounded-full flex items-center justify-center font-bold text-xs sm:text-sm flex-shrink-0">
                          3
                        </div>
                        <div>
                          <h4 className="font-semibold mb-1 text-sm sm:text-base">Complete Tasks</h4>
                          <p className="text-gray-400 text-xs sm:text-sm">
                            Participate in community events and referral programs
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Distribution */}
                <Card className="bg-white/5 border-yellow-500/20 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3 text-yellow-500 text-lg sm:text-xl">
                      <PieChart className="w-5 h-5 sm:w-6 sm:h-6" />
                      Token Distribution
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 sm:space-y-4">
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm sm:text-base">Early Adopters</span>
                          <span className="text-yellow-500 font-bold text-sm sm:text-base">300,000 MORI (30%)</span>
                        </div>
                        <div className="w-full bg-gray-700 rounded-full h-2">
                          <div className="bg-yellow-500 h-2 rounded-full" style={{ width: "30%" }} />
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm sm:text-base">Community Growth</span>
                          <span className="text-yellow-500 font-bold text-sm sm:text-base">500,000 MORI (50%)</span>
                        </div>
                        <div className="w-full bg-gray-700 rounded-full h-2">
                          <div className="bg-yellow-500 h-2 rounded-full" style={{ width: "50%" }} />
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm sm:text-base">Final Distribution</span>
                          <span className="text-yellow-500 font-bold text-sm sm:text-base">200,000 MORI (20%)</span>
                        </div>
                        <div className="w-full bg-gray-700 rounded-full h-2">
                          <div className="bg-yellow-500 h-2 rounded-full" style={{ width: "20%" }} />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* FAQ Section - Mobile Optimized */}
              <Card className="bg-white/5 border-yellow-500/20 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-xl sm:text-2xl">Frequently Asked Questions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 sm:space-y-4">
                    {faqItems.map((item, index) => (
                      <div key={index} className="border border-white/10 rounded-lg overflow-hidden">
                        <button
                          onClick={() => toggleFAQ(index)}
                          className="w-full p-3 sm:p-4 text-left flex items-center justify-between hover:bg-white/5 transition-colors"
                        >
                          <span className="font-semibold text-sm sm:text-base pr-4">{item.question}</span>
                          {openFAQ === index ? (
                            <ChevronUp className="w-4 h-4 sm:w-5 sm:h-5 text-yellow-500 flex-shrink-0" />
                          ) : (
                            <ChevronDown className="w-4 h-4 sm:w-5 sm:h-5 text-yellow-500 flex-shrink-0" />
                          )}
                        </button>
                        {openFAQ === index && (
                          <div className="p-3 sm:p-4 pt-0 text-gray-300 border-t border-white/10 text-sm sm:text-base">
                            {item.answer}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </section>

          {/* How to Buy Section - Mobile Optimized */}
          <section className="py-10 sm:py-20 px-4">
            <div className="max-w-6xl mx-auto">
              <div className="text-center mb-12 sm:mb-16">
                <h2 className="text-3xl sm:text-4xl font-bold mb-6 uppercase tracking-wider">How to Buy?</h2>
              </div>

              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-8 sm:mb-12">
                <Card className="bg-white/5 border-gray-600 hover:transform hover:-translate-y-2 transition-all duration-300">
                  <CardContent className="p-4 sm:p-6">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 bg-white rounded-xl flex items-center justify-center font-bold text-black text-lg sm:text-xl mb-3 sm:mb-4">
                      1
                    </div>
                    <p className="text-gray-300 text-sm sm:text-base">
                      Download and install a Solana wallet (Phantom, Solflare, or similar)
                    </p>
                  </CardContent>
                </Card>

                <Card className="bg-white/5 border-gray-600 hover:transform hover:-translate-y-2 transition-all duration-300">
                  <CardContent className="p-4 sm:p-6">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 bg-white rounded-xl flex items-center justify-center font-bold text-black text-lg sm:text-xl mb-3 sm:mb-4">
                      2
                    </div>
                    <p className="text-gray-300 text-sm sm:text-base">
                      Purchase SOL from a cryptocurrency exchange and transfer to your wallet
                    </p>
                  </CardContent>
                </Card>

                <Card className="bg-white/5 border-gray-600 hover:transform hover:-translate-y-2 transition-all duration-300">
                  <CardContent className="p-4 sm:p-6">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 bg-white rounded-xl flex items-center justify-center font-bold text-black text-lg sm:text-xl mb-3 sm:mb-4">
                      3
                    </div>
                    <p className="text-gray-300 text-sm sm:text-base">
                      Connect your wallet to Jupiter DEX or another Solana-based exchange
                    </p>
                  </CardContent>
                </Card>

                <Card className="bg-white/5 border-gray-600 hover:transform hover:-translate-y-2 transition-all duration-300">
                  <CardContent className="p-4 sm:p-6">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 bg-white rounded-xl flex items-center justify-center font-bold text-black text-lg sm:text-xl mb-3 sm:mb-4">
                      4
                    </div>
                    <p className="text-gray-300 text-sm sm:text-base">
                      Swap SOL for $MORI using the contract address provided above
                    </p>
                  </CardContent>
                </Card>
              </div>

              <div className="text-center">
                <Button
                  className="bg-yellow-500 text-black font-bold px-8 sm:px-12 py-3 sm:py-4 text-lg sm:text-xl rounded-lg hover:bg-yellow-400 transition-all duration-300 transform hover:scale-105 w-full sm:w-auto"
                  onClick={() =>
                    window.open("https://jup.ag/swap/SOL-8ZHE4ow1a2jjxuoMfyExuNamQNALv5ekZhsBn5nMDf5e", "_blank")
                  }
                >
                  Buy on Jupiter DEX
                </Button>
              </div>
            </div>
          </section>

          {/* Community Section - Mobile Optimized */}
          <section className="py-10 sm:py-20 px-4 bg-gradient-to-b from-gray-900 to-white relative">
            <div className="absolute inset-0 flex items-center justify-center">
              <h2 className="text-6xl sm:text-8xl lg:text-[12rem] font-bold text-white opacity-10 uppercase tracking-wider select-none">
                Community
              </h2>
            </div>

            <div className="max-w-6xl mx-auto relative z-10">
              <div className="text-center mb-12 sm:mb-16">
                <h2 className="text-3xl sm:text-4xl font-bold mb-6 text-black uppercase tracking-wider">
                  Join Our Community
                </h2>
                <p className="text-lg sm:text-xl text-black/70">
                  Connect with thousands of MORI holders and enthusiasts worldwide
                </p>
              </div>

              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
                <div className="text-center group">
                  <div className="w-16 h-16 sm:w-20 sm:h-20 mx-auto mb-4 bg-black/10 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                    <span className="text-2xl sm:text-3xl">𝕏</span>
                  </div>
                  <h3 className="text-lg sm:text-xl font-bold text-black mb-2">Twitter</h3>
                  <p className="text-black/70 mb-4 text-sm sm:text-base">
                    Follow us for the latest updates and announcements
                  </p>
                  <Button
                    variant="outline"
                    className="border-black text-black hover:bg-black hover:text-white bg-transparent text-sm sm:text-base"
                    onClick={() => window.open("https://x.com/MoriCoinCrypto", "_blank")}
                  >
                    Follow @MoriCoinCrypto
                  </Button>
                </div>

                <div className="text-center group">
                  <div className="w-16 h-16 sm:w-20 sm:h-20 mx-auto mb-4 bg-black/10 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                    <span className="text-2xl sm:text-3xl">✈</span>
                  </div>
                  <h3 className="text-lg sm:text-xl font-bold text-black mb-2">Telegram</h3>
                  <p className="text-black/70 mb-4 text-sm sm:text-base">
                    Join our active community chat and discussions
                  </p>
                  <Button
                    variant="outline"
                    className="border-black text-black hover:bg-black hover:text-white bg-transparent text-sm sm:text-base"
                    onClick={() => window.open("https://t.me/moricoin_official", "_blank")}
                  >
                    Join Telegram
                  </Button>
                </div>

                <div className="text-center group sm:col-span-2 lg:col-span-1">
                  <div className="w-16 h-16 sm:w-20 sm:h-20 mx-auto mb-4 bg-black/10 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                    <span className="text-2xl sm:text-3xl">▶</span>
                  </div>
                  <h3 className="text-lg sm:text-xl font-bold text-black mb-2">YouTube</h3>
                  <p className="text-black/70 mb-4 text-sm sm:text-base">
                    Watch educational content and project updates
                  </p>
                  <Button
                    variant="outline"
                    className="border-black text-black hover:bg-black hover:text-white bg-transparent text-sm sm:text-base"
                    onClick={() => window.open("https://www.youtube.com/@moriartymega", "_blank")}
                  >
                    Subscribe
                  </Button>
                </div>
              </div>
            </div>
          </section>
        </div>
      </main>

      {/* Solana Wallet Scanner */}
      {isWalletScannerOpen && (
        <SolanaWalletScanner isOpen={isWalletScannerOpen} onClose={() => setIsWalletScannerOpen(false)} />
      )}

      {/* Footer - Mobile Optimized */}
      <footer className="bg-gradient-to-b from-gray-900 to-black py-10 sm:py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8 sm:gap-12 items-start">
            {/* Left Content */}
            <div>
              <h3 className="text-xl sm:text-2xl font-bold mb-4 sm:mb-6">Contact Information</h3>
              <div className="space-y-3 sm:space-y-4 text-base sm:text-lg">
                <div>
                  <a
                    href="https://x.com/MoriCoinCrypto"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-yellow-500 hover:text-yellow-400 transition-colors"
                  >
                    Twitter: @MoriCoinCrypto
                  </a>
                </div>
                <div>
                  <a
                    href="https://t.me/moricoin_official"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-yellow-500 hover:text-yellow-400 transition-colors"
                  >
                    Telegram: @moricoin_official
                  </a>
                </div>
                <div>
                  <a
                    href="https://www.youtube.com/@moriartymega"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-yellow-500 hover:text-yellow-400 transition-colors"
                  >
                    YouTube: @moriartymega
                  </a>
                </div>
              </div>

              <div className="mt-6 sm:mt-8 text-gray-400 max-w-md">
                <p className="text-xs sm:text-sm leading-relaxed">
                  MORI is a community-driven cryptocurrency project. This website is for informational purposes only and
                  does not constitute financial advice. Always do your own research before investing.
                </p>
              </div>
            </div>

            {/* Right Content - CTA */}
            <div className="text-center md:text-right">
              <div className="mb-6 sm:mb-8">
                <h3 className="text-2xl sm:text-3xl font-bold mb-4">Ready to Join?</h3>
                <p className="text-gray-400 mb-4 sm:mb-6 text-sm sm:text-base">
                  Don't miss out on the biggest airdrop of 2025
                </p>
                <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center md:justify-end">
                  <Button
                    className="bg-gradient-to-r from-yellow-500 to-yellow-400 text-black font-bold px-6 sm:px-8 py-2 sm:py-3 rounded-full hover:from-yellow-400 hover:to-yellow-300 transition-all duration-300 text-sm sm:text-base"
                    onClick={() =>
                      window.open("https://jup.ag/swap/SOL-8ZHE4ow1a2jjxuoMfyExuNamQNALv5ekZhsBn5nMDf5e", "_blank")
                    }
                  >
                    Buy $MORI
                  </Button>
                  <Button
                    variant="outline"
                    className="border-yellow-500 text-yellow-500 hover:bg-yellow-500 hover:text-black px-6 sm:px-8 py-2 sm:py-3 rounded-full transition-all duration-300 text-sm sm:text-base bg-transparent"
                    onClick={() => window.open("https://t.me/moricoin_official", "_blank")}
                  >
                    Join Community
                  </Button>
                </div>
              </div>

              {/* Language Switcher */}
              <div className="flex items-center justify-center md:justify-end gap-4">
                <span className="text-gray-400 text-sm sm:text-base">Language:</span>
                <div className="flex bg-white/5 rounded-full p-1">
                  <button className="px-2 sm:px-3 py-1 text-gray-400 hover:text-yellow-500 transition-colors text-sm">
                    RU
                  </button>
                  <button className="px-2 sm:px-3 py-1 bg-yellow-500 text-black rounded-full font-semibold text-sm">
                    EN
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom */}
          <div className="border-t border-gray-800 mt-8 sm:mt-12 pt-6 sm:pt-8 text-center">
            <div className="flex justify-center mb-4">
              <Image
                src="/images/mori-logo-footer.png"
                alt="MORI Footer Logo"
                width={150}
                height={75}
                className="object-contain sm:w-48 sm:h-24"
              />
            </div>
            <p className="text-gray-400 text-sm sm:text-base">© 2025 MORI Coin. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
